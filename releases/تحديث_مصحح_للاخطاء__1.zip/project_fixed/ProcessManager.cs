using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace ARENA
{
    public class ProcessManager
    {
        private Dictionary<string, Process> _runningGames = new();

        [DllImport("user32.dll")] static extern bool   SetForegroundWindow(IntPtr h);
        [DllImport("user32.dll")] static extern bool   ShowWindow(IntPtr h, int cmd);
        [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] static extern bool   SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint f);
        [DllImport("user32.dll")] static extern bool   AttachThreadInput(uint a, uint b, bool f);
        [DllImport("user32.dll")] static extern uint   GetWindowThreadProcessId(IntPtr h, out uint pid);
        [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
        [DllImport("user32.dll")] static extern void   SwitchToThisWindow(IntPtr h, bool alt);
        [DllImport("user32.dll")] static extern bool   AllowSetForegroundWindow(uint pid);
        [DllImport("user32.dll")] static extern bool   BringWindowToTop(IntPtr h);
        [DllImport("user32.dll")] static extern bool   IsIconic(IntPtr h);
        // الحل 1: keybd_event
        [DllImport("user32.dll")] static extern void   keybd_event(byte vk, byte scan, uint flags, int extra);
        // الحل 2: SystemParametersInfo
        [DllImport("user32.dll")] static extern bool   SystemParametersInfo(uint a, uint p, IntPtr d, uint w);
        // ملء الشاشة: نجبر النافذة على تغطية الشاشة كاملاً
        [DllImport("user32.dll")] static extern int    GetSystemMetrics(int n);
        [DllImport("user32.dll")] static extern IntPtr MonitorFromWindow(IntPtr h, uint flags);
        [DllImport("user32.dll")] static extern bool   GetMonitorInfo(IntPtr hMon, ref MONITORINFO mi);
        [DllImport("user32.dll")] static extern IntPtr GetWindowLongPtr(IntPtr h, int idx);
        [DllImport("user32.dll")] static extern IntPtr SetWindowLongPtr(IntPtr h, int idx, IntPtr v);
        [DllImport("user32.dll")] static extern bool   PostMessage(IntPtr h, uint msg, IntPtr w, IntPtr l);

        [StructLayout(LayoutKind.Sequential)]
        struct MONITORINFO
        {
            public uint   cbSize;
            public RECT   rcMonitor;
            public RECT   rcWork;
            public uint   dwFlags;
        }
        [StructLayout(LayoutKind.Sequential)]
        struct RECT { public int L, T, R, B; }

        const int  GWL_STYLE        = -16;
        const int  GWL_EXSTYLE      = -20;
        const long WS_CAPTION       = 0x00C00000L; // title bar + border
        const long WS_THICKFRAME    = 0x00040000L; // resizable border
        const long WS_BORDER        = 0x00800000L;
        const long WS_MAXIMIZE      = 0x01000000L;
        const long WS_EX_TOPMOST    = 0x00000008L;
        const uint WM_SIZE          = 0x0005;
        const uint MONITOR_DEFAULTTONEAREST = 2;

        const uint SPI_SETFOREGROUNDLOCKTIMEOUT = 0x2001;
        const uint SPIF_UPDATEINIFILE = 0x01;
        const uint SPIF_SENDCHANGE    = 0x02;

        static readonly IntPtr HWND_TOPMOST   = new(-1);
        static readonly IntPtr HWND_NOTOPMOST = new(-2);
        const int  SW_SHOWMAXIMIZED = 3;
        const int  SW_RESTORE       = 9;
        const uint SWP_NOMOVE       = 0x0002;
        const uint SWP_NOSIZE       = 0x0001;
        const uint SWP_SHOWWINDOW   = 0x0040;

        public string?               LastLaunchedKey { get; private set; }
        public event Action?         OnAllGamesClosed;
        public event Action<string>? OnGameClosed;
        public string?               ExpectedProcessName { get; set; }

        // ═══════════════════════════════════════════════════════════════════════
        //  الحل 3 — ApplyForegroundUnlock
        //  يُستدعى مرة واحدة من MainWindow.OnLoaded
        //  يجمع Registry + SystemParametersInfo لإلغاء قفل الـ Foreground
        // ═══════════════════════════════════════════════════════════════════════
        public static void ApplyForegroundUnlock()
        {
            try
            {
                // 3A — ضبط Registry: ForegroundLockTimeout = 0
                // القيمة الافتراضية 200000ms — صفر = أي بروسيس يقدر يسرق الـ focus فوراً
                using var reg = Registry.CurrentUser.OpenSubKey(@"Control Panel\Desktop", writable: true);
                reg?.SetValue("ForegroundLockTimeout", 0, RegistryValueKind.DWord);
                reg?.SetValue("ForegroundFlashCount",  0, RegistryValueKind.DWord);

                // 3B — SystemParametersInfo: يطبّق التغيير فوراً بدون restart
                SystemParametersInfo(SPI_SETFOREGROUNDLOCKTIMEOUT, 0, IntPtr.Zero,
                    SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
            }
            catch (Exception ex) { Debug.WriteLine($"[ARENA] ForegroundUnlock: {ex.Message}"); }
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  تشغيل اللعبة
        // ═══════════════════════════════════════════════════════════════════════
        public void LaunchGame(string key, string path, string launchType)
        {
            if (_runningGames.TryGetValue(key, out var existing))
            {
                if (!existing.HasExited) { _ = ForceFocusAsync(existing); LastLaunchedKey = key; return; }
                _runningGames.Remove(key);
            }

            bool isUri = launchType == "uri" || path.StartsWith("steam://", StringComparison.OrdinalIgnoreCase)
                         || path.StartsWith("discord://", StringComparison.OrdinalIgnoreCase);
            bool isLnk = path.EndsWith(".lnk", StringComparison.OrdinalIgnoreCase);
            try
            {
                if (isUri)
                {
                    var before = new HashSet<int>(Process.GetProcesses().Select(p => p.Id));
                    Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
                    _ = WatchForNewProcessAsync(key, before);
                    LastLaunchedKey = key;
                    return;
                }

                // .lnk اختصارات
                if (isLnk)
                {
                    var before = new HashSet<int>(Process.GetProcesses().Select(p => p.Id));
                    Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
                    _ = WatchForNewProcessAsync(key, before);
                    LastLaunchedKey = key;
                    return;
                }

                // فصل المسار عن الـ arguments
                // مثال: "C:\...\Update.exe" --processStart Discord.exe
                string exePath = path;
                string args = "";

                // لو المسار يبدأ بـ " — يعني فيه مسار مع فراغات + arguments
                if (path.StartsWith("\""))
                {
                    int endQuote = path.IndexOf('"', 1);
                    if (endQuote > 0)
                    {
                        exePath = path.Substring(1, endQuote - 1);
                        args = path.Substring(endQuote + 1).Trim();
                    }
                }
                // لو المسار فيه .exe وبعده فراغ + arguments
                else
                {
                    int exeIdx = path.IndexOf(".exe ", StringComparison.OrdinalIgnoreCase);
                    if (exeIdx < 0) exeIdx = path.IndexOf(".EXE ", StringComparison.OrdinalIgnoreCase);
                    if (exeIdx > 0)
                    {
                        exePath = path.Substring(0, exeIdx + 4);
                        args = path.Substring(exeIdx + 5).Trim();
                    }
                }

                var psi = new ProcessStartInfo(exePath) { UseShellExecute = true };
                if (!string.IsNullOrEmpty(args)) psi.Arguments = args;

                string? dir = Path.GetDirectoryName(exePath);
                if (!string.IsNullOrEmpty(dir) && Directory.Exists(dir)) psi.WorkingDirectory = dir;

                var before2 = new HashSet<int>(Process.GetProcesses().Select(p => p.Id));
                var proc = Process.Start(psi);
                if (proc != null)
                {
                    TrackProcess(key, proc);
                }
                else
                {
                    _ = WatchForNewProcessAsync(key, before2);
                    LastLaunchedKey = key;
                }
            }
            catch (Exception ex) { Debug.WriteLine($"[ARENA] Launch {path}: {ex.Message}"); throw; }
        }

        void TrackProcess(string key, Process proc)
        {
            _runningGames[key] = proc;
            LastLaunchedKey    = key;
            proc.EnableRaisingEvents = true;
            proc.Exited += (_, _) =>
            {
                _runningGames.Remove(key);
                OnGameClosed?.Invoke(key);
                if (!IsAnyGameRunning()) OnAllGamesClosed?.Invoke();
            };
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  مراقبة ألعاب Steam
        // ═══════════════════════════════════════════════════════════════════════
        static readonly HashSet<string> _ignore = new(StringComparer.OrdinalIgnoreCase)
        {
            "steam","steamwebhelper","gameoverlayui","steamservice",
            "steamerrorreporter64","steamerrorreporter","steamlauncher","bootstrapper",
            "epicgameslauncher","easyanticheat","battlenet","agent",
            "crashhandler","crashreporter","ealauncher","origin","originwebhelperservice",
            "conhost","cmd","powershell","explorer","runtimebroker","svchost","csrss",
            "dwm","taskhostw","sihost","fontdrvhost","lsass","services",
            "msedgewebview2","webview2","arena"
        };

        async Task WatchForNewProcessAsync(string key, HashSet<int> before, int maxMs = 35000)
        {
            int w = 0;
            while (w < maxMs)
            {
                await Task.Delay(500); w += 500;
                if (_runningGames.ContainsKey(key)) return;

                foreach (var p in Process.GetProcesses())
                {
                    try
                    {
                        if (before.Contains(p.Id))         continue;
                        if (_ignore.Contains(p.ProcessName)) continue;
                        if (p.HasExited)                    continue;
                        if (p.MainWindowHandle == IntPtr.Zero) continue;

                        Debug.WriteLine($"[ARENA] Steam proc: {p.ProcessName} pid={p.Id}");
                        TrackProcess(key, p);
                        await Task.Delay(400);
                        await ForceFocusAsync(p);
                        return;
                    }
                    catch { }
                }
            }
            Debug.WriteLine($"[ARENA] WatchForNewProcess timeout key={key}");
            OnGameClosed?.Invoke(key);
            if (!IsAnyGameRunning()) OnAllGamesClosed?.Invoke();
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  FocusAfterLaunchAsync — للألعاب EXE
        // ═══════════════════════════════════════════════════════════════════════
        public async Task FocusAfterLaunchAsync(string key, int maxMs = 14000)
        {
            int w = 0;
            while (w < maxMs)
            {
                await Task.Delay(300); w += 300;
                if (!_runningGames.TryGetValue(key, out var proc) || proc.HasExited) continue;
                proc.Refresh();
                if (proc.MainWindowHandle == IntPtr.Zero) continue;

                // الحل 4 — WaitForInputIdle: انتظر حتى تنهي اللعبة تحميلها
                try { proc.WaitForInputIdle(1000); } catch { }
                await Task.Delay(250);
                await ForceFocusAsync(proc);
                return;
            }
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  ForceFocusAsync — 3 محاولات بفترات متزايدة
        // ═══════════════════════════════════════════════════════════════════════
        public async Task ForceFocusAsync(Process proc)
        {
            int[] delays = { 0, 350, 700 };
            foreach (int d in delays)
            {
                if (d > 0) await Task.Delay(d);
                try
                {
                    proc.Refresh();
                    if (proc.HasExited || proc.MainWindowHandle == IntPtr.Zero) continue;
                    bool ok = FocusProcessNow(proc);
                    if (ok) { Debug.WriteLine("[ARENA] ForceFocus succeeded"); return; }
                }
                catch { }
            }
            Debug.WriteLine("[ARENA] ForceFocus: all attempts failed");
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  ForceFullscreen — يجبر النافذة على ملء الشاشة كاملاً
        //  3 طبقات: ShowWindow + SetWindowPos بأبعاد الشاشة + WM_SIZE
        // ═══════════════════════════════════════════════════════════════════════
        static void ForceFullscreen(IntPtr hwnd)
        {
            try
            {
                // الطبقة 1: اجلب أبعاد الشاشة الفعلية من المونيتور الذي تعيش فيه النافذة
                IntPtr hMon = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
                var mi = new MONITORINFO { cbSize = (uint)Marshal.SizeOf<MONITORINFO>() };
                int x, y, w, h;
                if (GetMonitorInfo(hMon, ref mi))
                {
                    x = mi.rcMonitor.L; y = mi.rcMonitor.T;
                    w = mi.rcMonitor.R - mi.rcMonitor.L;
                    h = mi.rcMonitor.B - mi.rcMonitor.T;
                }
                else
                {
                    // fallback: GetSystemMetrics
                    x = 0; y = 0;
                    w = GetSystemMetrics(0);  // SM_CXSCREEN
                    h = GetSystemMetrics(1);  // SM_CYSCREEN
                }

                // الطبقة 2: أزل حدود النافذة (border + title bar)
                // بعض الألعاب تبقى بـ windowed mode بسبب الـ WS_CAPTION
                var style    = GetWindowLongPtr(hwnd, GWL_STYLE).ToInt64();
                var newStyle = style & ~(WS_CAPTION | WS_THICKFRAME | WS_BORDER);
                // أضف WS_MAXIMIZE
                newStyle |= WS_MAXIMIZE;
                SetWindowLongPtr(hwnd, GWL_STYLE, new IntPtr(newStyle));

                // الطبقة 3: SetWindowPos بأبعاد الشاشة الكاملة
                // SWP_FRAMECHANGED يجبر Windows يعيد حساب الـ frame بعد تغيير الـ style
                const uint SWP_FRAMECHANGED = 0x0020;
                const uint SWP_NOZORDER     = 0x0004;
                SetWindowPos(hwnd, HWND_TOPMOST, x, y, w, h,
                    SWP_FRAMECHANGED | SWP_SHOWWINDOW);

                // الطبقة 4: أرسل WM_SIZE لإخبار النافذة بالحجم الجديد
                // بعض الألعاب تحتاج هذا الـ message لتعيد رسم نفسها بالحجم الجديد
                IntPtr lParam = new IntPtr((h << 16) | (w & 0xFFFF));
                PostMessage(hwnd, WM_SIZE, new IntPtr(2), lParam); // SIZE_MAXIMIZED = 2

                // الطبقة 5: أزل HWND_TOPMOST بعدها — اللعبة تشتغل عادي
                SetWindowPos(hwnd, HWND_NOTOPMOST, x, y, w, h,
                    SWP_FRAMECHANGED | SWP_NOZORDER);

                Debug.WriteLine($"[ARENA] ForceFullscreen: {w}x{h} at ({x},{y})");
            }
            catch (Exception ex) { Debug.WriteLine($"[ARENA] ForceFullscreen: {ex.Message}"); }
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  FocusProcessNow — الجوهر: 5 حلول في طبقة واحدة
        // ═══════════════════════════════════════════════════════════════════════
        bool FocusProcessNow(Process proc)
        {
            try
            {
                proc.Refresh();
                IntPtr hwnd = proc.MainWindowHandle;
                if (hwnd == IntPtr.Zero || proc.HasExited) return false;

                // ── الحل 1: keybd_event ──────────────────────────────────────
                // يجدد "آخر وقت input" ← يجعل Windows يعتقد أن المستخدم فعّال
                // هذا يكسر قاعدة "الإذن ينتهي بعد أول input event"
                keybd_event(0, 0, 0, 0);
                keybd_event(0, 0, 2, 0);

                // ── الحل 2: AllowSetForegroundWindow ─────────────────────────
                AllowSetForegroundWindow((uint)proc.Id);
                AllowSetForegroundWindow(0xFFFFFFFF);

                // ── الحل 3: AttachThreadInput (ثلاثي) ────────────────────────
                // نربط thread الـ foreground الحالي + thread النافذة الهدف
                // بـ thread هذا البروسيس — يجعل Windows يتعامل معهم كـ thread واحد
                IntPtr fgHwnd = GetForegroundWindow();
                uint   fgTid  = GetWindowThreadProcessId(fgHwnd, out _);
                uint   myTid  = GetCurrentThreadId();
                uint   tgTid  = GetWindowThreadProcessId(hwnd, out _);
                bool   a1 = false, a2 = false;

                if (fgTid != 0 && fgTid != myTid) a1 = AttachThreadInput(fgTid, myTid, true);
                if (tgTid != 0 && tgTid != myTid && tgTid != fgTid)
                    a2 = AttachThreadInput(tgTid, myTid, true);
                try
                {
                    // ── الحل 4: HWND_TOPMOST + ShowWindow + SetForegroundWindow ──
                    SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0,
                        SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
                    if (IsIconic(hwnd)) ShowWindow(hwnd, SW_RESTORE);
                    ShowWindow(hwnd, SW_SHOWMAXIMIZED);
                    BringWindowToTop(hwnd);
                    SetForegroundWindow(hwnd);
                    SwitchToThisWindow(hwnd, true);

                    // ── ملء الشاشة: أجبر النافذة على تغطية الشاشة كاملاً ──
                    ForceFullscreen(hwnd);
                }
                finally
                {
                    if (a1) AttachThreadInput(fgTid, myTid, false);
                    if (a2) AttachThreadInput(tgTid, myTid, false);
                }
                return GetForegroundWindow() == hwnd;
            }
            catch (Exception ex) { Debug.WriteLine($"[ARENA] FocusNow: {ex.Message}"); return false; }
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  Public helpers
        // ═══════════════════════════════════════════════════════════════════════
        public bool IsRunning(string key) =>
            _runningGames.TryGetValue(key, out var p) && !p.HasExited;

        public void FocusGame(string key)
        {
            if (_runningGames.TryGetValue(key, out var p) && !p.HasExited)
                _ = ForceFocusAsync(p);
        }

        public void FocusLastGame() { if (LastLaunchedKey != null) FocusGame(LastLaunchedKey); }

        public bool IsAnyGameRunning()
        {
            foreach (var kv in new Dictionary<string, Process>(_runningGames))
            {
                if (!kv.Value.HasExited) return true;
                _runningGames.Remove(kv.Key);
            }
            return false;
        }

        public void KillGame(string key)
        {
            if (_runningGames.TryGetValue(key, out var p))
            {
                try { if (!p.HasExited) p.Kill(); } catch { }
                _runningGames.Remove(key);
                if (!IsAnyGameRunning()) OnAllGamesClosed?.Invoke();
            }
        }

        public void MinimizeAllGames()
        {
            foreach (var p in new Dictionary<string, Process>(_runningGames).Values)
            {
                try { if (!p.HasExited) { p.Refresh(); ShowWindow(p.MainWindowHandle, 6); } }
                catch { }
            }
        }

        public void KillAllGames()
        {
            foreach (var p in _runningGames.Values)
            { try { if (!p.HasExited) p.Kill(); } catch { } }
            _runningGames.Clear(); LastLaunchedKey = null;
        }

        public Dictionary<string, bool> GetRunningStatus()
        {
            var r = new Dictionary<string, bool>();
            foreach (var kv in new Dictionary<string, Process>(_runningGames))
            {
                bool on = !kv.Value.HasExited; r[kv.Key] = on;
                if (!on) _runningGames.Remove(kv.Key);
            }
            return r;
        }

        public List<string> GetRunningKeys()
        {
            var k = new List<string>();
            foreach (var kv in new Dictionary<string, Process>(_runningGames))
                if (!kv.Value.HasExited) k.Add(kv.Key);
            return k;
        }

        public IntPtr GetForegroundGameWindow()
        {
            var fg = GetForegroundWindow();
            foreach (var p in _runningGames.Values)
                if (!p.HasExited && p.MainWindowHandle == fg) return fg;
            return IntPtr.Zero;
        }
    }
}
