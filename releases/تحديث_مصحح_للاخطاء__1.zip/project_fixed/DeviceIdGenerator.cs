using System;
using System.Management;
using System.Net.NetworkInformation;
using System.Security.Cryptography;
using System.Text;

namespace ARENA
{
    public static class DeviceIdGenerator
    {
        public static string Generate()
        {
            string cpuId = GetCpuId();
            string macAddress = GetMacAddress();
            string hddSerial = GetHddSerial();

            string combined = $"{cpuId}|{macAddress}|{hddSerial}";

            using var sha = SHA256.Create();
            var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(combined));
            return BitConverter.ToString(bytes).Replace("-", "").ToLower();
        }

        private static string GetCpuId()
        {
            try
            {
                using var searcher = new ManagementObjectSearcher("SELECT ProcessorId FROM Win32_Processor");
                foreach (ManagementObject obj in searcher.Get())
                    return obj["ProcessorId"]?.ToString() ?? "UNKNOWN_CPU";
            }
            catch { }
            return "UNKNOWN_CPU";
        }

        private static string GetMacAddress()
        {
            try
            {
                foreach (var nic in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (nic.OperationalStatus == OperationalStatus.Up &&
                        nic.NetworkInterfaceType != NetworkInterfaceType.Loopback)
                    {
                        return nic.GetPhysicalAddress().ToString();
                    }
                }
            }
            catch { }
            return "UNKNOWN_MAC";
        }

        private static string GetHddSerial()
        {
            try
            {
                using var searcher = new ManagementObjectSearcher("SELECT SerialNumber FROM Win32_DiskDrive");
                foreach (ManagementObject obj in searcher.Get())
                    return obj["SerialNumber"]?.ToString()?.Trim() ?? "UNKNOWN_HDD";
            }
            catch { }
            return "UNKNOWN_HDD";
        }
    }
}
