using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;

namespace ARENA
{
    public class ArenaConfig
    {
        public bool cloudEnabled { get; set; } = false;
        public string pcName { get; set; } = "";
        public string adminPassword { get; set; } = "";
        public string lastGame { get; set; } = "";
        public string appVersion { get; set; } = "1.0.0";
        public string installedVersion { get; set; } = "";
        public bool showUpdateInNormalPanel { get; set; } = false;
    }

    public static class ConfigManager
    {
        private static readonly string ConfigPath =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "arena_config.json");

        public static ArenaConfig Load()
        {
            if (!File.Exists(ConfigPath))
            {
                var def = new ArenaConfig
                {
                    cloudEnabled = false,
                    pcName = "",
                    adminPassword = HashSHA256("0000"),
                    lastGame = ""
                };
                Save(def);
                return def;
            }
            var json = File.ReadAllText(ConfigPath);
            var config = JsonConvert.DeserializeObject<ArenaConfig>(json) ?? new ArenaConfig();
            // تأكد إنه في باسورد دائماً
            if (string.IsNullOrEmpty(config.adminPassword))
            {
                config.adminPassword = HashSHA256("0000");
                Save(config);
            }
            return config;
        }

        public static void Save(ArenaConfig config)
        {
            File.WriteAllText(ConfigPath, JsonConvert.SerializeObject(config, Formatting.Indented));
        }

        public static string HashSHA256(string input)
        {
            using var sha = SHA256.Create();
            var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(input));
            return BitConverter.ToString(bytes).Replace("-", "").ToLower();
        }
    }
}
