using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using Microsoft.Win32;
using Newtonsoft.Json;

namespace ARENA
{
    public class DetectedGame
    {
        public string name       { get; set; } = "";
        public string path       { get; set; } = "";
        public string launchType { get; set; } = "exe";
        public string source     { get; set; } = "";
        public string appId      { get; set; } = "";
    }

    public static class GameDetector
    {
        public static List<DetectedGame> DetectAll()
        {
            var games = new List<DetectedGame>();
            try { games.AddRange(DetectSteam()); } catch { }
            try { games.AddRange(DetectEpic()); } catch { }
            try { games.AddRange(DetectBattleNet()); } catch { }
            try { games.AddRange(DetectEA()); } catch { }
            try { games.AddRange(DetectGamePass()); } catch { }
            try { games.AddRange(DetectDirect()); } catch { }
            return games;
        }

        static List<DetectedGame> DetectSteam()
        {
            var games = new List<DetectedGame>();
            string steamPath = Registry.GetValue(
                @"HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath", null)?.ToString()
                ?? Registry.GetValue(
                @"HKEY_LOCAL_MACHINE\SOFTWARE\Valve\Steam", "InstallPath", null)?.ToString() ?? "";
            if (string.IsNullOrEmpty(steamPath)) return games;

            var libs = new List<string> { Path.Combine(steamPath, "steamapps") };
            string vdf = Path.Combine(steamPath, "steamapps", "libraryfolders.vdf");
            if (File.Exists(vdf))
            {
                foreach (Match m in Regex.Matches(File.ReadAllText(vdf), "\"path\"\\s+\"([^\"]+)\""))
                {
                    string sa = Path.Combine(m.Groups[1].Value.Replace("\\\\", "\\"), "steamapps");
                    if (Directory.Exists(sa)) libs.Add(sa);
                }
            }

            foreach (var lib in libs)
            {
                foreach (var acf in Directory.GetFiles(lib, "appmanifest_*.acf"))
                {
                    try
                    {
                        var text = File.ReadAllText(acf);
                        var appId = VdfVal(text, "appid");
                        var name = VdfVal(text, "name");
                        if (string.IsNullOrEmpty(name) || appId == "228980") continue;
                        if (VdfVal(text, "StateFlags") != "4") continue;
                        games.Add(new DetectedGame { name = name, path = $"steam://rungameid/{appId}", launchType = "uri", source = "Steam", appId = appId });
                    }
                    catch { }
                }
            }
            return games;
        }

        static List<DetectedGame> DetectEpic()
        {
            var games = new List<DetectedGame>();
            string mfDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Epic", "EpicGamesLauncher", "Data", "Manifests");
            if (!Directory.Exists(mfDir)) return games;
            foreach (var file in Directory.GetFiles(mfDir, "*.item"))
            {
                try
                {
                    dynamic obj = JsonConvert.DeserializeObject(File.ReadAllText(file))!;
                    string name = obj.DisplayName ?? "", exe = obj.LaunchExecutable ?? "", dir = obj.InstallLocation ?? "";
                    if (string.IsNullOrEmpty(name)) continue;
                    string full = Path.Combine(dir, exe);
                    if (File.Exists(full))
                        games.Add(new DetectedGame { name = name, path = full, launchType = "exe", source = "Epic", appId = obj.AppName ?? "" });
                }
                catch { }
            }
            return games;
        }

        static List<DetectedGame> DetectBattleNet()
        {
            var games = new List<DetectedGame>();
            string bnet = Registry.GetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Blizzard Entertainment\Battle.net\Capabilities", "ApplicationIcon", null)?.ToString() ?? "";
            bool installed = !string.IsNullOrEmpty(bnet) || File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Battle.net", "Battle.net.exe"));
            if (!installed) return games;
            var list = new[] {
                ("Call of Duty: Warzone", "battlenet://WLBY"), ("Call of Duty: MW III", "battlenet://ZEUS"),
                ("Overwatch 2", "battlenet://Pro"), ("Diablo IV", "battlenet://D4"),
                ("World of Warcraft", "battlenet://WoW"), ("Hearthstone", "battlenet://WTCG"),
                ("Diablo III", "battlenet://D3"), ("StarCraft II", "battlenet://S2"),
            };
            foreach (var (n, u) in list)
                games.Add(new DetectedGame { name = n, path = u, launchType = "uri", source = "Battle.net" });
            return games;
        }

        static List<DetectedGame> DetectEA()
        {
            var games = new List<DetectedGame>();
            var dirs = new[] {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "EA Games"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "EA Games"),
                @"C:\EA Games", @"D:\EA Games"
            };
            foreach (var dir in dirs)
            {
                if (!Directory.Exists(dir)) continue;
                foreach (var sub in Directory.GetDirectories(dir))
                {
                    foreach (var exe in Directory.GetFiles(sub, "*.exe", SearchOption.TopDirectoryOnly))
                    {
                        var fn = Path.GetFileNameWithoutExtension(exe).ToLower();
                        if (fn.Contains("install") || fn.Contains("unins") || fn.Contains("crash")) continue;
                        games.Add(new DetectedGame { name = Path.GetFileName(sub), path = exe, launchType = "exe", source = "EA" });
                        break;
                    }
                }
            }
            return games;
        }

        static List<DetectedGame> DetectGamePass()
        {
            var games = new List<DetectedGame>();
            try
            {
                // استخدم PowerShell لجلب كل الـ Store apps المثبتة
                var psi = new System.Diagnostics.ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = "-NoProfile -Command \"Get-AppxPackage | Where-Object {$_.SignatureKind -eq 'Store' -and $_.IsFramework -eq $false} | Select-Object Name, PackageFamilyName, InstallLocation | ConvertTo-Json -Compress\"",
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };
                var proc = System.Diagnostics.Process.Start(psi);
                if (proc == null) return games;

                string output = proc.StandardOutput.ReadToEnd();
                proc.WaitForExit(10000);
                if (string.IsNullOrEmpty(output)) return games;

                // Parse JSON output
                dynamic? items = JsonConvert.DeserializeObject(output);
                if (items == null) return games;

                // لو عنصر واحد بس يرجع object مو array
                var list = new List<dynamic>();
                if (items is Newtonsoft.Json.Linq.JArray arr)
                    foreach (var item in arr) list.Add(item);
                else
                    list.Add(items);

                // فلتر — بس الألعاب (نستبعد system apps)
                var skipPrefixes = new[] {
                    "Microsoft.Windows", "Microsoft.UI", "Microsoft.NET", "Microsoft.VCLibs",
                    "Microsoft.Services", "Microsoft.ScreenSketch", "Microsoft.Paint",
                    "Microsoft.MSPaint", "Microsoft.Office", "Microsoft.OneDrive",
                    "Microsoft.Edge", "Microsoft.Bing", "Microsoft.GetHelp",
                    "Microsoft.StorePurchase", "Microsoft.Desktop", "Microsoft.Advertising",
                    "Microsoft.AAD", "Microsoft.AccountsControl", "Microsoft.AsyncTextService",
                    "Microsoft.BioEnrollment", "Microsoft.CBSPreview", "Microsoft.CredDialogHost",
                    "Microsoft.ECApp", "Microsoft.LockApp", "Microsoft.MicrosoftEdge",
                    "Microsoft.PPIProjection", "Microsoft.Win32WebViewHost",
                    "Microsoft.XboxIdentityProvider", "Microsoft.XboxSpeechToTextOverlay",
                    "Microsoft.XboxGameCallableUI", "Microsoft.Xbox.TCUI",
                    "Microsoft.XboxGamingOverlay", "Microsoft.GamingApp",
                    "MicrosoftWindows.", "NcsiUwpApp", "Windows.",
                    "InputApp", "MicrosoftTeams", "Clipchamp", "Microsoft.Todos",
                    "Microsoft.People", "Microsoft.Photos", "Microsoft.ZuneMusic",
                    "Microsoft.ZuneVideo", "Microsoft.YourPhone", "Microsoft.Wallet",
                    "Microsoft.549981C3F5F10", // Cortana
                    "Microsoft.WindowsStore", "Microsoft.WindowsCalculator",
                    "Microsoft.WindowsCamera", "Microsoft.WindowsAlarms",
                    "Microsoft.WindowsFeedbackHub", "Microsoft.WindowsMaps",
                    "Microsoft.WindowsNotepad", "Microsoft.WindowsSoundRecorder",
                    "Microsoft.WindowsTerminal", "Microsoft.SecHealthUI",
                    "Microsoft.MixedReality", "Microsoft.HEIFImageExtension",
                    "Microsoft.HEVCVideoExtension", "Microsoft.VP9VideoExtensions",
                    "Microsoft.WebMediaExtensions", "Microsoft.WebpImageExtension",
                    "Microsoft.RawImageExtension", "Microsoft.AV1VideoExtension",
                };

                foreach (var item in list)
                {
                    string name = item.Name?.ToString() ?? "";
                    string pfn = item.PackageFamilyName?.ToString() ?? "";
                    string installLoc = item.InstallLocation?.ToString() ?? "";

                    if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(pfn)) continue;

                    // استبعد system apps
                    bool skip = false;
                    foreach (var prefix in skipPrefixes)
                    {
                        if (name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                        { skip = true; break; }
                    }
                    if (skip) continue;

                    // حاول نجيب اسم حلو من AppxManifest
                    string displayName = name;
                    try
                    {
                        string manifest = Path.Combine(installLoc, "AppxManifest.xml");
                        if (File.Exists(manifest))
                        {
                            string xml = File.ReadAllText(manifest);
                            // جلب DisplayName من الـ manifest
                            var match = Regex.Match(xml, "<DisplayName>([^<]+)</DisplayName>");
                            if (match.Success && !match.Groups[1].Value.StartsWith("ms-resource"))
                                displayName = match.Groups[1].Value;
                        }
                    }
                    catch { }

                    // جلب App ID من manifest
                    string appId = "App";
                    try
                    {
                        string manifest = Path.Combine(installLoc, "AppxManifest.xml");
                        if (File.Exists(manifest))
                        {
                            string xml = File.ReadAllText(manifest);
                            var match = Regex.Match(xml, "<Application\\s+Id=\"([^\"]+)\"");
                            if (match.Success) appId = match.Groups[1].Value;
                        }
                    }
                    catch { }

                    string uri = $"shell:AppsFolder\\{pfn}!{appId}";

                    games.Add(new DetectedGame
                    {
                        name = displayName,
                        path = uri,
                        launchType = "uri",
                        source = "Game Pass",
                        appId = pfn
                    });
                }
            }
            catch { }
            return games;
        }

        static List<DetectedGame> DetectDirect()
        {
            var games = new List<DetectedGame>();
            var dirs = new[] { @"C:\Games", @"D:\Games", @"E:\Games",
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Games"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Games") };
            var skip = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "unins000","uninstall","setup","install","crash","redist","vcredist" };
            foreach (var dir in dirs)
            {
                if (!Directory.Exists(dir)) continue;
                foreach (var sub in Directory.GetDirectories(dir))
                {
                    try
                    {
                        foreach (var exe in Directory.GetFiles(sub, "*.exe", SearchOption.TopDirectoryOnly))
                        {
                            if (skip.Contains(Path.GetFileNameWithoutExtension(exe).ToLower())) continue;
                            games.Add(new DetectedGame { name = Path.GetFileName(sub), path = exe, launchType = "exe", source = "Direct" });
                            break;
                        }
                    }
                    catch { }
                }
            }
            return games;
        }

        static string VdfVal(string text, string key)
        {
            var m = Regex.Match(text, $"\"{Regex.Escape(key)}\"\\s+\"([^\"]+)\"", RegexOptions.IgnoreCase);
            return m.Success ? m.Groups[1].Value : "";
        }
    }
}
