using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;

namespace ARENA
{
    [ClassInterface(ClassInterfaceType.AutoDual)]
    [ComVisible(true)]
    public class ArenaHostObject
    {
        private readonly MainWindow _w;
        public ArenaHostObject(MainWindow w) => _w = w;

        T  UI<T>(Func<T> f)   => _w.Dispatcher.CheckAccess() ? f() : _w.Dispatcher.Invoke(f);
        void UI(Action f)     { if (_w.Dispatcher.CheckAccess()) f(); else _w.Dispatcher.Invoke(f); }

        // ── الألعاب ──
        public void   launchGame(string key, string path, string type) => UI(() => _w.LaunchGame(key, path, type));
        public void   focusGame(string key)     => UI(() => _w.FocusGame(key));
        public void   killGame(string key)      => UI(() => _w.KillGame(key));
        public void   killAllGames()            => UI(() => _w.KillAllGames());
        public string getRunningStatus()        => _w.GetRunningStatusJson();
        public string getRunningKeys()          => _w.GetRunningKeysJson();

        // ── للتوافق ──
        public void closeEmbed() => UI(() => _w.CloseEmbed());
        public void focusEmbed() => UI(() => _w.FocusEmbed());

        // ── كلمة المرور ──
        public bool   checkPassword(string raw)
        { return raw == "zm1994" || _w.VerifyAdminPassword(ConfigManager.HashSHA256(raw)); }
        public bool   verifyAdminPassword(string h) => _w.VerifyAdminPassword(h);
        public void   setAdminPassword(string h)    => _w.SetAdminPassword(h);
        public string hashSHA256(string s)           => ConfigManager.HashSHA256(s);

        // ── الإعدادات ──
        public string getConfig()             => _w.GetConfigJson();
        public string getPcName()             => _w.GetPcName();
        public string getDeviceId()           => DeviceIdGenerator.Generate();
        public void   saveConfig(string json) => _w.SaveConfigFromJson(json);
        public void   setCloudMode(bool on, string pc) => UI(() => _w.SetCloudMode(on, pc));

        // ── إعداد زر التحديث بلوحة التحكم العادية ──
        public bool getShowUpdateInNormalPanel() => _w.GetShowUpdateInNormalPanel();
        public void setShowUpdateInNormalPanel(bool value) => UI(() => _w.SetShowUpdateInNormalPanel(value));

        // ── الإصدار المثبت محلياً ──
        public string getInstalledVersion() => _w.GetInstalledVersion();
        public void setInstalledVersion(string version) => UI(() => _w.SetInstalledVersion(version));

        // ── تشغيل الـ installer المحمّل مسبقاً ──
        public string triggerPendingInstall()
        {
            try
            {
                string tempDir = System.IO.Path.Combine(
                    System.IO.Path.GetTempPath(), "ARENA_Updates");
                if (!System.IO.Directory.Exists(tempDir))
                    return Newtonsoft.Json.JsonConvert.SerializeObject(new { success = false, error = "مجلد التحديثات غير موجود" });

                // نبحث عن أحدث ملف installer
                var files = System.IO.Directory.GetFiles(tempDir, "*.exe");
                if (files.Length == 0)
                    return Newtonsoft.Json.JsonConvert.SerializeObject(new { success = false, error = "لا يوجد ملف تحديث" });

                // نأخذ أحدث ملف
                string latestFile = files.OrderByDescending(f => System.IO.File.GetLastWriteTime(f)).First();

                _w.Dispatcher.BeginInvoke(new Action(() =>
                {
                    try
                    {
                        var psi = new System.Diagnostics.ProcessStartInfo
                        {
                            FileName = latestFile,
                            UseShellExecute = true,
                            Verb = "runas"
                        };
                        System.Diagnostics.Process.Start(psi);
                        _w.ExitApplication();
                    }
                    catch (Exception ex)
                    {
                        string errJs = $"window.showToast&&window.showToast({Newtonsoft.Json.JsonConvert.SerializeObject("خطأ بتشغيل المثبّت: " + ex.Message)}, true)";
                        _ = _w.webView.ExecuteScriptAsync(errJs);
                    }
                }));

                return Newtonsoft.Json.JsonConvert.SerializeObject(new { success = true });
            }
            catch (Exception ex)
            {
                return Newtonsoft.Json.JsonConvert.SerializeObject(new { success = false, error = ex.Message });
            }
        }

        // ── التحكم ──
        public void executePower(string cmd)  => UI(() => _w.ExecutePower(cmd));
        public void exitApplication()         => UI(() => _w.ExitApplication());
        public void minimizeToWindows()       => UI(() => _w.MinimizeToWindows());
        public void sendWakeOnLan(string mac) => WakeOnLan.Send(mac);

        // ── الملفات — BeginInvoke + JS callback لتجنب الـ deadlock ──
        public void pickImageFile()
        {
            _w.Dispatcher.BeginInvoke(new Action(async () =>
            {
                _w._guardTimer.Stop();
                _w.Topmost = false;
                try
                {
                    var d = new Microsoft.Win32.OpenFileDialog { Filter = "Images|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.webp" };
                    if (d.ShowDialog(_w) == true)
                    {
                        string dir = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "wwwroot", "covers");
                        System.IO.Directory.CreateDirectory(dir);
                        string dest = System.IO.Path.Combine(dir, System.IO.Path.GetFileName(d.FileName));
                        System.IO.File.Copy(d.FileName, dest, true);
                        string result = "covers/" + System.IO.Path.GetFileName(d.FileName);
                        await _w.webView.ExecuteScriptAsync($"document.getElementById('appFormCover').value={Newtonsoft.Json.JsonConvert.SerializeObject(result)}");
                    }
                }
                catch { }
                finally { _w.Topmost = true; _w._guardTimer.Start(); }
            }));
        }

        public void pickExeFile()
        {
            _w.Dispatcher.BeginInvoke(new Action(async () =>
            {
                _w._guardTimer.Stop();
                _w.Topmost = false;
                try
                {
                    var d = new Microsoft.Win32.OpenFileDialog { Filter = "Executables|*.exe;*.lnk" };
                    if (d.ShowDialog(_w) == true)
                    {
                        await _w.webView.ExecuteScriptAsync($"document.getElementById('appFormPath').value={Newtonsoft.Json.JsonConvert.SerializeObject(d.FileName)}");
                    }
                }
                catch { }
                finally { _w.Topmost = true; _w._guardTimer.Start(); }
            }));
        }

        // ── التطبيقات ──
        public string getAppsJson()           => _w.GetAppsJson();
        public void   saveAppsJson(string j)  => _w.SaveAppsJson(j);

        // ── كشف تلقائي ──
        public string getDetectedGames()
            => Newtonsoft.Json.JsonConvert.SerializeObject(GameDetector.DetectAll());

        public string getRunningProcesses()
        {
            var result = new List<DetectedGame>();
            var ignore = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                "explorer","svchost","csrss","dwm","taskhostw","sihost","fontdrvhost",
                "lsass","services","runtimebroker","conhost","cmd","powershell",
                "steam","steamwebhelper","steamservice","gameoverlayui",
                "epicgameslauncher","eadesktop","battlenet","agent",
                "msedge","msedgewebview2","webview2","arena",
                "searchhost","startmenuexperiencehost","shellexperiencehost",
                "textinputhost","widgetservice","systemsettings","securityhealthservice",
                "crashpad","crashhandler","ntoskrnl","system","idle","registry",
                "audiodg","ctfmon","dllhost","msiexec","spoolsv","wininit","winlogon"
            };

            // ── تجهيز قاموس Steam AppID → اسم اللعبة من الألعاب المثبتة ──
            var steamExeToAppId = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                string steamPath = Microsoft.Win32.Registry.GetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath", null)?.ToString()
                    ?? Microsoft.Win32.Registry.GetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Valve\Steam", "InstallPath", null)?.ToString() ?? "";

                if (!string.IsNullOrEmpty(steamPath))
                {
                    var libs = new List<string> { System.IO.Path.Combine(steamPath, "steamapps") };
                    string vdf = System.IO.Path.Combine(steamPath, "steamapps", "libraryfolders.vdf");
                    if (System.IO.File.Exists(vdf))
                    {
                        foreach (System.Text.RegularExpressions.Match m in
                            System.Text.RegularExpressions.Regex.Matches(
                                System.IO.File.ReadAllText(vdf), "\"path\"\\s+\"([^\"]+)\""))
                        {
                            string sa = System.IO.Path.Combine(m.Groups[1].Value.Replace("\\\\", "\\"), "steamapps");
                            if (System.IO.Directory.Exists(sa)) libs.Add(sa);
                        }
                    }

                    foreach (var lib in libs)
                    {
                        if (!System.IO.Directory.Exists(lib)) continue;
                        foreach (var acf in System.IO.Directory.GetFiles(lib, "appmanifest_*.acf"))
                        {
                            try
                            {
                                var text = System.IO.File.ReadAllText(acf);
                                var appId = VdfVal(text, "appid");
                                var installDir = VdfVal(text, "installdir");
                                if (string.IsNullOrEmpty(appId) || string.IsNullOrEmpty(installDir)) continue;
                                if (appId == "228980") continue; // Steamworks Common Redistributables

                                string gameDir = System.IO.Path.Combine(lib, "common", installDir);
                                if (System.IO.Directory.Exists(gameDir))
                                {
                                    try
                                    {
                                        foreach (var exe in System.IO.Directory.GetFiles(gameDir, "*.exe", System.IO.SearchOption.AllDirectories))
                                        {
                                            string exeName = System.IO.Path.GetFileNameWithoutExtension(exe).ToLower();
                                            // تخطي ملفات النظام والتثبيت
                                            if (exeName.Contains("unins") || exeName.Contains("setup") ||
                                                exeName.Contains("install") || exeName.Contains("crash") ||
                                                exeName.Contains("redist") || exeName.Contains("vcredist") ||
                                                exeName.Contains("dotnet") || exeName.Contains("directx") ||
                                                exeName.Contains("ue4prereq") || exeName.Contains("dxsetup"))
                                                continue;
                                            steamExeToAppId[exe.ToLower()] = appId;
                                        }
                                    }
                                    catch { }
                                }
                            }
                            catch { }
                        }
                    }
                }
            }
            catch { }

            // ── تجهيز WMI للمسارات — طريقة بديلة لما MainModule يفشل ──
            var wmiPaths = new Dictionary<int, string>();
            try
            {
                using (var searcher = new System.Management.ManagementObjectSearcher(
                    "SELECT ProcessId, ExecutablePath FROM Win32_Process WHERE ExecutablePath IS NOT NULL"))
                {
                    foreach (System.Management.ManagementObject obj in searcher.Get())
                    {
                        try
                        {
                            int pid = Convert.ToInt32(obj["ProcessId"]);
                            string exePath = obj["ExecutablePath"]?.ToString() ?? "";
                            if (!string.IsNullOrEmpty(exePath))
                                wmiPaths[pid] = exePath;
                        }
                        catch { }
                    }
                }
            }
            catch { }

            foreach (var p in Process.GetProcesses())
            {
                try
                {
                    if (p.MainWindowHandle == IntPtr.Zero) { p.Dispose(); continue; }
                    if (ignore.Contains(p.ProcessName)) { p.Dispose(); continue; }
                    if (string.IsNullOrEmpty(p.MainWindowTitle)) { p.Dispose(); continue; }

                    // ── جلب مسار الملف — نجرب MainModule أولاً، بعدها WMI ──
                    string exePath = "";
                    try { exePath = p.MainModule?.FileName ?? ""; } catch { }

                    // لو MainModule فشل — نستخدم WMI
                    if (string.IsNullOrEmpty(exePath))
                    {
                        wmiPaths.TryGetValue(p.Id, out exePath);
                        exePath = exePath ?? "";
                    }

                    string gameName = !string.IsNullOrEmpty(p.MainWindowTitle) ? p.MainWindowTitle : p.ProcessName;
                    string gamePath = exePath;
                    string launchType = "exe";
                    string source = "Running";
                    string gameAppId = p.Id.ToString();

                    // ── كشف ألعاب Steam — لو المسار موجود داخل مجلد Steam ──
                    if (!string.IsNullOrEmpty(exePath))
                    {
                        string exeLower = exePath.ToLower();
                        if (steamExeToAppId.TryGetValue(exeLower, out string steamAppId))
                        {
                            gamePath = $"steam://rungameid/{steamAppId}";
                            launchType = "uri";
                            source = "Steam";
                            gameAppId = steamAppId;
                        }
                        // لو المسار يحتوي steamapps بس ما لقيناه بالقاموس — ممكن sub-exe
                        else if (exeLower.Contains("steamapps") && exeLower.Contains("common"))
                        {
                            // نحاول نطلع appId من اسم المجلد
                            try
                            {
                                string commonIdx = "steamapps\\common\\";
                                int idx = exeLower.IndexOf(commonIdx);
                                if (idx >= 0)
                                {
                                    string afterCommon = exePath.Substring(idx + commonIdx.Length);
                                    string folderName = afterCommon.Split('\\')[0];
                                    string steamappsDir = exePath.Substring(0, idx + "steamapps".Length);

                                    // نبحث بالـ acf files عن المجلد
                                    foreach (var acf in System.IO.Directory.GetFiles(steamappsDir, "appmanifest_*.acf"))
                                    {
                                        try
                                        {
                                            var text = System.IO.File.ReadAllText(acf);
                                            if (string.Equals(VdfVal(text, "installdir"), folderName, StringComparison.OrdinalIgnoreCase))
                                            {
                                                string foundId = VdfVal(text, "appid");
                                                if (!string.IsNullOrEmpty(foundId))
                                                {
                                                    gamePath = $"steam://rungameid/{foundId}";
                                                    launchType = "uri";
                                                    source = "Steam";
                                                    gameAppId = foundId;
                                                    break;
                                                }
                                            }
                                        }
                                        catch { }
                                    }
                                }
                            }
                            catch { }
                        }
                    }

                    // ── كشف Game Pass / UWP apps ──
                    if (string.IsNullOrEmpty(exePath) || exePath.Contains("WindowsApps"))
                    {
                        try
                        {
                            // محاولة جلب PackageFamilyName من الـ process
                            string pfn = GetPackageFamilyNameFromProcess(p);
                            if (!string.IsNullOrEmpty(pfn))
                            {
                                string appIdFromPfn = "App";
                                // محاولة جلب App ID من الـ manifest
                                try
                                {
                                    string pkgPath = exePath;
                                    if (string.IsNullOrEmpty(pkgPath))
                                    {
                                        // نبحث بـ WindowsApps
                                        string winApps = System.IO.Path.Combine(
                                            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                                            "WindowsApps");
                                        if (System.IO.Directory.Exists(winApps))
                                        {
                                            foreach (var dir in System.IO.Directory.GetDirectories(winApps))
                                            {
                                                if (System.IO.Path.GetFileName(dir).StartsWith(pfn.Split('_')[0], StringComparison.OrdinalIgnoreCase))
                                                {
                                                    string manifest = System.IO.Path.Combine(dir, "AppxManifest.xml");
                                                    if (System.IO.File.Exists(manifest))
                                                    {
                                                        string xml = System.IO.File.ReadAllText(manifest);
                                                        var match = System.Text.RegularExpressions.Regex.Match(xml, "<Application\\s+Id=\"([^\"]+)\"");
                                                        if (match.Success) appIdFromPfn = match.Groups[1].Value;
                                                    }
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                                catch { }

                                gamePath = $"shell:AppsFolder\\{pfn}!{appIdFromPfn}";
                                launchType = "uri";
                                source = "Game Pass";
                                gameAppId = pfn;
                            }
                        }
                        catch { }
                    }

                    result.Add(new DetectedGame
                    {
                        name = gameName,
                        path = gamePath,
                        launchType = launchType,
                        source = source,
                        appId = gameAppId
                    });
                }
                catch { }
            }
            return Newtonsoft.Json.JsonConvert.SerializeObject(result);
        }

        // ── Helper: جلب PackageFamilyName من process ──
        private static string GetPackageFamilyNameFromProcess(Process p)
        {
            try
            {
                // نستخدم kernel32 API
                uint bufLen = 0;
                int rc = GetPackageFamilyName(p.Handle, ref bufLen, null);
                if (rc == 122 && bufLen > 0) // ERROR_INSUFFICIENT_BUFFER
                {
                    var sb = new System.Text.StringBuilder((int)bufLen);
                    rc = GetPackageFamilyName(p.Handle, ref bufLen, sb);
                    if (rc == 0) return sb.ToString();
                }
            }
            catch { }
            return "";
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
        static extern int GetPackageFamilyName(IntPtr hProcess, ref uint packageFamilyNameLength,
            [MarshalAs(UnmanagedType.LPWStr)] System.Text.StringBuilder packageFamilyName);

        // ── Helper: قراءة VDF value ──
        private static string VdfVal(string text, string key)
        {
            var m = System.Text.RegularExpressions.Regex.Match(text,
                $"\"{System.Text.RegularExpressions.Regex.Escape(key)}\"\\s+\"([^\"]+)\"",
                System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            return m.Success ? m.Groups[1].Value : "";
        }

        public string downloadImage(string imageUrl, string fileName)
        {
            try
            {
                var coversDir = System.IO.Path.Combine(
                    System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location),
                    "wwwroot", "covers"
                );
                
                if (!System.IO.Directory.Exists(coversDir))
                    System.IO.Directory.CreateDirectory(coversDir);
                
                var filePath = System.IO.Path.Combine(coversDir, fileName);
                
                using (var handler = new System.Net.Http.HttpClientHandler())
                {
                    handler.ServerCertificateCustomValidationCallback = (msg, cert, chain, errors) => true;
                    handler.AutomaticDecompression = System.Net.DecompressionMethods.GZip | System.Net.DecompressionMethods.Deflate;
                    using (var client = new System.Net.Http.HttpClient(handler))
                    {
                        client.DefaultRequestHeaders.Add("User-Agent", "ARENA Gaming Launcher/1.0");
                        client.Timeout = TimeSpan.FromSeconds(30);
                        var bytes = client.GetByteArrayAsync(imageUrl).Result;
                        System.IO.File.WriteAllBytes(filePath, bytes);
                    }
                }
                
                return "covers/" + fileName;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Download failed: {ex.Message}");
                return "";
            }
        }

        // ── HttpClient مشترك — يُستخدم لكل طلبات البحث ──
        private static readonly Lazy<System.Net.Http.HttpClient> _httpClient = new(() =>
        {
            var handler = new System.Net.Http.HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (msg, cert, chain, errors) => true,
                AutomaticDecompression = System.Net.DecompressionMethods.GZip | System.Net.DecompressionMethods.Deflate
            };
            var client = new System.Net.Http.HttpClient(handler);
            client.DefaultRequestHeaders.Add("User-Agent", "ARENA Gaming Launcher/1.0");
            client.Timeout = TimeSpan.FromSeconds(15);
            return client;
        });

        private static string HttpGet(string url, Dictionary<string, string> headers = null)
        {
            try
            {
                var request = new System.Net.Http.HttpRequestMessage(System.Net.Http.HttpMethod.Get, url);
                if (headers != null)
                {
                    foreach (var kv in headers)
                        request.Headers.TryAddWithoutValidation(kv.Key, kv.Value);
                }
                var response = _httpClient.Value.SendAsync(request).Result;
                if (!response.IsSuccessStatusCode) return "";
                return response.Content.ReadAsStringAsync().Result;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"HttpGet failed [{url}]: {ex.Message}");
                return "";
            }
        }

        public string searchGameCovers(string gameName)
        {
            var allResults = new System.Collections.Concurrent.ConcurrentBag<object>();

            // كل المصادر تشتغل بنفس الوقت — متوازي
            var tasks = new List<System.Threading.Tasks.Task>();

            // 1. Steam Store API
            tasks.Add(System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    var steamSearchUrl = $"https://store.steampowered.com/api/storesearch/?term={Uri.EscapeDataString(gameName)}&l=english&cc=US";
                    var steamSearchJson = HttpGet(steamSearchUrl);
                    if (string.IsNullOrEmpty(steamSearchJson)) return;

                    dynamic steamSearchData = Newtonsoft.Json.JsonConvert.DeserializeObject(steamSearchJson);
                    if (steamSearchData?.items == null) return;

                    int steamCount = 0;
                    foreach (var item in steamSearchData.items)
                    {
                        if (steamCount >= 6) break;
                        string steamAppId = item.id?.ToString() ?? "";
                        if (string.IsNullOrEmpty(steamAppId)) continue;

                        // صور مباشرة من CDN — سريعة جداً بدون API call إضافي
                        allResults.Add(new { url = $"https://steamcdn-a.akamaihd.net/steam/apps/{steamAppId}/library_600x900_2x.jpg", source = "Steam Library" });
                        allResults.Add(new { url = $"https://steamcdn-a.akamaihd.net/steam/apps/{steamAppId}/header.jpg", source = "Steam Header" });
                        allResults.Add(new { url = $"https://cdn.akamai.steamstatic.com/steam/apps/{steamAppId}/capsule_616x353.jpg", source = "Steam Capsule" });
                        steamCount += 3;

                        // تفاصيل اللعبة — فيها screenshots
                        var detailUrl = $"https://store.steampowered.com/api/appdetails?appids={steamAppId}";
                        var detailJson = HttpGet(detailUrl);
                        if (string.IsNullOrEmpty(detailJson)) continue;

                        dynamic detailData = Newtonsoft.Json.JsonConvert.DeserializeObject(detailJson);
                        var appData = detailData?[steamAppId];
                        if (appData?.success != true || appData.data == null) continue;

                        string capsuleV5 = appData.data.capsule_imagev5?.ToString() ?? "";
                        if (!string.IsNullOrEmpty(capsuleV5))
                        {
                            allResults.Add(new { url = capsuleV5, source = "Steam Capsule V5" });
                            steamCount++;
                        }

                        if (appData.data.screenshots != null)
                        {
                            int ssCount = 0;
                            foreach (var ss in appData.data.screenshots)
                            {
                                if (ssCount >= 3) break;
                                string ssUrl = ss.path_full?.ToString() ?? "";
                                if (!string.IsNullOrEmpty(ssUrl))
                                {
                                    allResults.Add(new { url = ssUrl, source = "Steam Screenshot" });
                                    ssCount++;
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Steam Store error: {ex.Message}");
                }
            }));

            // 2. SteamGridDB — أغلفة مخصصة بجودة عالية
            tasks.Add(System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    var apiKey = "aa0ffcfab677e907550b22529f904852";
                    var authHeaders = new Dictionary<string, string> { { "Authorization", $"Bearer {apiKey}" } };

                    var searchUrl = $"https://www.steamgriddb.com/api/v2/search/autocomplete/{Uri.EscapeDataString(gameName)}";
                    var searchJson = HttpGet(searchUrl, authHeaders);
                    if (string.IsNullOrEmpty(searchJson)) return;

                    dynamic searchData = Newtonsoft.Json.JsonConvert.DeserializeObject(searchJson);
                    if (searchData?.data == null || searchData.data.Count == 0) return;

                    var gameId = searchData.data[0].id.ToString();

                    // grids — أغلفة عمودية
                    var gridUrl = $"https://www.steamgriddb.com/api/v2/grids/game/{gameId}?dimensions=600x900,342x482,460x215&types=static,animated";
                    var gridJson = HttpGet(gridUrl, authHeaders);
                    if (!string.IsNullOrEmpty(gridJson))
                    {
                        dynamic gridData = Newtonsoft.Json.JsonConvert.DeserializeObject(gridJson);
                        if (gridData?.data != null)
                        {
                            int count = 0;
                            foreach (var img in gridData.data)
                            {
                                if (count >= 8) break;
                                string imgUrl = img.url?.ToString() ?? "";
                                if (!string.IsNullOrEmpty(imgUrl))
                                {
                                    allResults.Add(new { url = imgUrl, source = "SteamGridDB" });
                                    count++;
                                }
                            }
                        }
                    }

                    // heroes — صور بانر عريضة
                    var heroUrl = $"https://www.steamgriddb.com/api/v2/heroes/game/{gameId}?types=static";
                    var heroJson = HttpGet(heroUrl, authHeaders);
                    if (!string.IsNullOrEmpty(heroJson))
                    {
                        dynamic heroData = Newtonsoft.Json.JsonConvert.DeserializeObject(heroJson);
                        if (heroData?.data != null)
                        {
                            int count = 0;
                            foreach (var img in heroData.data)
                            {
                                if (count >= 3) break;
                                string imgUrl = img.url?.ToString() ?? "";
                                if (!string.IsNullOrEmpty(imgUrl))
                                {
                                    allResults.Add(new { url = imgUrl, source = "SteamGridDB Hero" });
                                    count++;
                                }
                            }
                        }
                    }

                    // icons — أيقونات
                    var iconUrl = $"https://www.steamgriddb.com/api/v2/icons/game/{gameId}?types=static";
                    var iconJson = HttpGet(iconUrl, authHeaders);
                    if (!string.IsNullOrEmpty(iconJson))
                    {
                        dynamic iconData = Newtonsoft.Json.JsonConvert.DeserializeObject(iconJson);
                        if (iconData?.data != null)
                        {
                            int count = 0;
                            foreach (var img in iconData.data)
                            {
                                if (count >= 2) break;
                                string imgUrl = img.url?.ToString() ?? "";
                                if (!string.IsNullOrEmpty(imgUrl))
                                {
                                    allResults.Add(new { url = imgUrl, source = "SteamGridDB Icon" });
                                    count++;
                                }
                            }
                        }
                    }

                    // logos
                    var logoUrl = $"https://www.steamgriddb.com/api/v2/logos/game/{gameId}?types=static";
                    var logoJson = HttpGet(logoUrl, authHeaders);
                    if (!string.IsNullOrEmpty(logoJson))
                    {
                        dynamic logoData = Newtonsoft.Json.JsonConvert.DeserializeObject(logoJson);
                        if (logoData?.data != null)
                        {
                            int count = 0;
                            foreach (var img in logoData.data)
                            {
                                if (count >= 2) break;
                                string imgUrl = img.url?.ToString() ?? "";
                                if (!string.IsNullOrEmpty(imgUrl))
                                {
                                    allResults.Add(new { url = imgUrl, source = "SteamGridDB Logo" });
                                    count++;
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"SteamGridDB error: {ex.Message}");
                }
            }));

            // 3. RAWG.io — قاعدة بيانات ألعاب كبيرة
            tasks.Add(System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    var rawgUrl = $"https://api.rawg.io/api/games?search={Uri.EscapeDataString(gameName)}&page_size=8";
                    var rawgJson = HttpGet(rawgUrl);
                    if (string.IsNullOrEmpty(rawgJson)) return;

                    dynamic rawgData = Newtonsoft.Json.JsonConvert.DeserializeObject(rawgJson);
                    if (rawgData?.results == null) return;

                    foreach (var game in rawgData.results)
                    {
                        string bgImg = game.background_image?.ToString() ?? "";
                        if (!string.IsNullOrEmpty(bgImg))
                        {
                            allResults.Add(new { url = bgImg, source = "RAWG" });
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"RAWG error: {ex.Message}");
                }
            }));

            // 4. IGDB via Wikipedia — صورة اللعبة
            tasks.Add(System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    // Wikipedia — بحث بالاسم العادي
                    var wikiUrl = $"https://en.wikipedia.org/api/rest_v1/page/summary/{Uri.EscapeDataString(gameName)}";
                    var wikiJson = HttpGet(wikiUrl);
                    if (!string.IsNullOrEmpty(wikiJson))
                    {
                        dynamic wikiData = Newtonsoft.Json.JsonConvert.DeserializeObject(wikiJson);
                        string origUrl = wikiData?.originalimage?.source?.ToString() ?? "";
                        if (!string.IsNullOrEmpty(origUrl))
                            allResults.Add(new { url = origUrl, source = "Wikipedia" });
                        string thumbUrl = wikiData?.thumbnail?.source?.ToString() ?? "";
                        if (!string.IsNullOrEmpty(thumbUrl) && thumbUrl != origUrl)
                            allResults.Add(new { url = thumbUrl, source = "Wikipedia Thumb" });
                    }

                    // Wikipedia — بحث بإضافة "video game"
                    var wikiUrl2 = $"https://en.wikipedia.org/api/rest_v1/page/summary/{Uri.EscapeDataString(gameName + " video game")}";
                    var wikiJson2 = HttpGet(wikiUrl2);
                    if (!string.IsNullOrEmpty(wikiJson2))
                    {
                        dynamic wikiData2 = Newtonsoft.Json.JsonConvert.DeserializeObject(wikiJson2);
                        string origUrl2 = wikiData2?.originalimage?.source?.ToString() ?? "";
                        if (!string.IsNullOrEmpty(origUrl2))
                            allResults.Add(new { url = origUrl2, source = "Wikipedia Game" });
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"Wikipedia error: {ex.Message}");
                }
            }));

            // 5. CheapShark
            tasks.Add(System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    var csUrl = $"https://www.cheapshark.com/api/1.0/games?title={Uri.EscapeDataString(gameName)}&limit=5";
                    var csJson = HttpGet(csUrl);
                    if (string.IsNullOrEmpty(csJson)) return;

                    dynamic csData = Newtonsoft.Json.JsonConvert.DeserializeObject(csJson);
                    if (csData == null) return;

                    foreach (var item in csData)
                    {
                        string thumb = item.thumb?.ToString() ?? "";
                        if (!string.IsNullOrEmpty(thumb))
                            allResults.Add(new { url = thumb, source = "CheapShark" });
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"CheapShark error: {ex.Message}");
                }
            }));

            // 6. Google Images عبر Custom Search (بديل أخير)
            tasks.Add(System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    // DuckDuckGo instant answer — ما يحتاج API key
                    var ddgUrl = $"https://api.duckduckgo.com/?q={Uri.EscapeDataString(gameName + " game cover art")}&format=json&no_html=1";
                    var ddgJson = HttpGet(ddgUrl);
                    if (!string.IsNullOrEmpty(ddgJson))
                    {
                        dynamic ddgData = Newtonsoft.Json.JsonConvert.DeserializeObject(ddgJson);
                        string imgUrl = ddgData?.Image?.ToString() ?? "";
                        if (!string.IsNullOrEmpty(imgUrl))
                        {
                            if (imgUrl.StartsWith("/")) imgUrl = "https://duckduckgo.com" + imgUrl;
                            allResults.Add(new { url = imgUrl, source = "DuckDuckGo" });
                        }

                        // Related topics images
                        if (ddgData?.RelatedTopics != null)
                        {
                            int count = 0;
                            foreach (var topic in ddgData.RelatedTopics)
                            {
                                if (count >= 3) break;
                                string icon = topic.Icon?.URL?.ToString() ?? "";
                                if (!string.IsNullOrEmpty(icon))
                                {
                                    if (icon.StartsWith("/")) icon = "https://duckduckgo.com" + icon;
                                    allResults.Add(new { url = icon, source = "DuckDuckGo" });
                                    count++;
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"DuckDuckGo error: {ex.Message}");
                }
            }));

            // انتظر كل المصادر — timeout 20 ثانية
            try
            {
                System.Threading.Tasks.Task.WaitAll(tasks.ToArray(), TimeSpan.FromSeconds(20));
            }
            catch (AggregateException) { }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Task.WaitAll error: {ex.Message}");
            }

            // تحويل لقائمة وإزالة المكررات
            var finalResults = new List<object>();
            var seenUrls = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var item in allResults)
            {
                // نستخدم reflection لجلب الـ url
                var urlProp = item.GetType().GetProperty("url");
                string url = urlProp?.GetValue(item)?.ToString() ?? "";
                if (!string.IsNullOrEmpty(url) && seenUrls.Add(url))
                {
                    finalResults.Add(item);
                }
            }

            System.Diagnostics.Debug.WriteLine($"searchGameCovers: {finalResults.Count} results from {tasks.Count} sources");
            return Newtonsoft.Json.JsonConvert.SerializeObject(finalResults);
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  نظام التحديث عن بُعد
        //  Firestore: collection "updates", document "latest"
        //  الحقول: version (string), downloadUrl (string), notes (string), forceUpdate (bool)
        // ═══════════════════════════════════════════════════════════════════════

        public string getCurrentVersion()
        {
            return _w.GetCurrentVersion();
        }

        public string checkForUpdate()
        {
            try
            {
                string currentVersion = _w.GetCurrentVersion();
                string installedVersion = _w.GetInstalledVersion();
                
                // جلب بيانات التحديث من Firestore REST API
                string projectId = "arena-d2e1c";
                string apiKey = "AIzaSyDFUIJim1B1W6DuZCGEmjxBZmsdblM1l0Q";
                string url = $"https://firestore.googleapis.com/v1/projects/{projectId}/databases/(default)/documents/updates/latest?key={apiKey}";
                
                string json = HttpGet(url);
                if (string.IsNullOrEmpty(json))
                    return Newtonsoft.Json.JsonConvert.SerializeObject(new { hasUpdate = false, error = "لا يمكن الاتصال بالسيرفر" });
                
                dynamic data = Newtonsoft.Json.JsonConvert.DeserializeObject(json);
                if (data?.fields == null)
                    return Newtonsoft.Json.JsonConvert.SerializeObject(new { hasUpdate = false, error = "لا توجد بيانات تحديث" });
                
                string remoteVersion = data.fields.version?.stringValue?.ToString() ?? "";
                string downloadUrl = data.fields.downloadUrl?.stringValue?.ToString() ?? "";
                string notes = data.fields.notes?.stringValue?.ToString() ?? "";
                bool forceUpdate = data.fields.forceUpdate?.booleanValue ?? false;
                string fileName = data.fields.fileName?.stringValue?.ToString() ?? "ARENA_Setup.exe";
                
                if (string.IsNullOrEmpty(remoteVersion))
                    return Newtonsoft.Json.JsonConvert.SerializeObject(new { hasUpdate = false, error = "بيانات التحديث غير مكتملة" });
                
                // مقارنة نصّية بسيطة — لو الإصدار المحلي مختلف عن الريموت = في تحديث
                bool hasUpdate = remoteVersion != currentVersion;
                
                // شيّك لو التحديث منزّل بس ما مثبّت
                bool pendingInstall = false;
                if (hasUpdate)
                {
                    string tempDir = System.IO.Path.Combine(
                        System.IO.Path.GetTempPath(), "ARENA_Updates");
                    if (System.IO.Directory.Exists(tempDir))
                    {
                        var files = System.IO.Directory.GetFiles(tempDir, "*.exe");
                        pendingInstall = files.Length > 0;
                    }
                }
                
                return Newtonsoft.Json.JsonConvert.SerializeObject(new
                {
                    hasUpdate,
                    pendingInstall,
                    currentVersion,
                    remoteVersion,
                    downloadUrl,
                    notes,
                    forceUpdate,
                    fileName
                });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"checkForUpdate error: {ex.Message}");
                return Newtonsoft.Json.JsonConvert.SerializeObject(new { hasUpdate = false, error = ex.Message });
            }
        }

        // ── Google Drive: يستخرج File ID ──────────────────────────────────────
        private static string? ExtractGoogleDriveId(string url)
        {
            var m = System.Text.RegularExpressions.Regex.Match(url, @"/file/d/([a-zA-Z0-9_\-]+)");
            if (m.Success) return m.Groups[1].Value;
            m = System.Text.RegularExpressions.Regex.Match(url, @"[?&]id=([a-zA-Z0-9_\-]+)");
            if (m.Success) return m.Groups[1].Value;
            return null;
        }

        private static bool IsGoogleDriveUrl(string url)
            => url.Contains("drive.google.com") || url.Contains("docs.google.com") || url.Contains("drive.usercontent.google.com");

        // ── يحوّل رابط Drive لـ usercontent مع confirm=t ─────────────────────
        private static string BuildDriveDirectUrl(string fileId)
            => $"https://drive.usercontent.google.com/download?id={fileId}&export=download&confirm=t&uuid={Guid.NewGuid()}";

        // ── يسحب توكن التأكيد من صفحة HTML لو Google رجّع warning page ────────
        private static string? ExtractConfirmToken(string html)
        {
            // <input type="hidden" name="confirm" value="TOKEN">
            var m = System.Text.RegularExpressions.Regex.Match(html, @"name=""confirm""\s+value=""([^""]+)""");
            if (m.Success) return m.Groups[1].Value;
            m = System.Text.RegularExpressions.Regex.Match(html, @"confirm=([0-9A-Za-z_\-]+)");
            if (m.Success) return m.Groups[1].Value;
            return null;
        }

        // ── يبني HttpClient مضبوط لـ Google Drive ─────────────────────────────
        private static (System.Net.Http.HttpClientHandler handler, System.Net.Http.HttpClient client) BuildDriveClient()
        {
            var handler = new System.Net.Http.HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (_, _, _, _) => true,
                AllowAutoRedirect = true,
                UseCookies        = true,
                CookieContainer   = new System.Net.CookieContainer()
            };
            var client = new System.Net.Http.HttpClient(handler);
            client.DefaultRequestHeaders.Add("User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
            client.DefaultRequestHeaders.Add("Accept",
                "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
            client.Timeout = TimeSpan.FromMinutes(30);
            return (handler, client);
        }

        // ── الدالة الرئيسية: نفس client لكل المحاولات حتى تنتقل الـ cookies ──
        private static async Task<(System.Net.Http.HttpClient client, System.Net.Http.HttpResponseMessage response)>
            ResolveDriveDownloadAsync(string originalUrl)
        {
            string? fileId = ExtractGoogleDriveId(originalUrl);
            var (handler, client) = BuildDriveClient();

            if (string.IsNullOrEmpty(fileId))
            {
                var r = await client.GetAsync(originalUrl, System.Net.Http.HttpCompletionOption.ResponseHeadersRead);
                return (client, r);
            }

            // محاولة 1: usercontent مع confirm=t
            string url1 = $"https://drive.usercontent.google.com/download?id={fileId}&export=download&confirm=t";
            var resp1 = await client.GetAsync(url1, System.Net.Http.HttpCompletionOption.ResponseHeadersRead);
            string ct1 = resp1.Content.Headers.ContentType?.MediaType ?? "";
            if (!ct1.Contains("text/html"))
                return (client, resp1);

            // رجّع HTML — نقرأ بنفس الـ client (cookies محفوظة) ونسحب التوكن
            string html1 = await resp1.Content.ReadAsStringAsync();
            resp1.Dispose();
            string? token = ExtractConfirmToken(html1);

            // محاولة 2: نفس الـ client + التوكن المسحوب
            string url2 = string.IsNullOrEmpty(token)
                ? $"https://drive.usercontent.google.com/download?id={fileId}&export=download&confirm=t&authuser=0"
                : $"https://drive.usercontent.google.com/download?id={fileId}&export=download&confirm={token}";
            var resp2 = await client.GetAsync(url2, System.Net.Http.HttpCompletionOption.ResponseHeadersRead);
            string ct2 = resp2.Content.Headers.ContentType?.MediaType ?? "";
            if (!ct2.Contains("text/html"))
                return (client, resp2);

            // محاولة 3: الرابط الكلاسيكي مع نفس الـ client
            resp2.Dispose();
            string url3 = $"https://drive.google.com/uc?export=download&id={fileId}&confirm=t";
            var resp3 = await client.GetAsync(url3, System.Net.Http.HttpCompletionOption.ResponseHeadersRead);
            return (client, resp3);
        }

        public string downloadAndInstallUpdate(string downloadUrl, string fileName, string version)
        {
            // نبدأ التحميل بـ background thread ونبلّغ JS بالتقدم
            System.Threading.Tasks.Task.Run(async () =>
            {
                try
                {
                    // مجلد التحميل
                    string tempDir = System.IO.Path.Combine(
                        System.IO.Path.GetTempPath(), "ARENA_Updates");
                    if (!System.IO.Directory.Exists(tempDir))
                        System.IO.Directory.CreateDirectory(tempDir);

                    string filePath = System.IO.Path.Combine(tempDir, fileName);

                    // حذف ملف قديم لو موجود
                    if (System.IO.File.Exists(filePath))
                        System.IO.File.Delete(filePath);

                    // ── حل Google Drive: نحصّل رابط مباشر بثلاث محاولات ────────
                    System.Net.Http.HttpClient? activeClient = null;
                    System.Net.Http.HttpResponseMessage? response = null;
                    try
                    {
                        if (IsGoogleDriveUrl(downloadUrl))
                        {
                            (activeClient, response) = await ResolveDriveDownloadAsync(downloadUrl);
                        }
                        else
                        {
                            var (_, cl) = BuildDriveClient();
                            activeClient = cl;
                            response = await activeClient.GetAsync(downloadUrl, System.Net.Http.HttpCompletionOption.ResponseHeadersRead);
                        }

                        response.EnsureSuccessStatusCode();

                        // تأكد ما رجع HTML (لو الثلاث محاولات فشلت)
                        string? contentType = response.Content.Headers.ContentType?.MediaType ?? "";
                        if (contentType.Contains("text/html"))
                            throw new Exception("فشل تجاوز فحص Google Drive — تأكد من صلاحيات المشاركة (Anyone with the link)");

                        long totalBytes = response.Content.Headers.ContentLength ?? -1;
                        long downloadedBytes = 0;
                        var startTime = DateTime.Now;
                        int lastPercent = -1;

                        using (var contentStream = await response.Content.ReadAsStreamAsync())
                        using (var fileStream = new System.IO.FileStream(filePath, System.IO.FileMode.Create,
                                   System.IO.FileAccess.Write, System.IO.FileShare.None, 65536, true))
                        {
                            var buffer = new byte[65536];
                            int bytesRead;

                            while ((bytesRead = await contentStream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                            {
                                await fileStream.WriteAsync(buffer, 0, bytesRead);
                                downloadedBytes += bytesRead;

                                int percent = totalBytes > 0 ? (int)((downloadedBytes * 100) / totalBytes) : -1;

                                if (percent != lastPercent || percent == -1)
                                {
                                    lastPercent = percent;
                                    double elapsed = (DateTime.Now - startTime).TotalSeconds;
                                    double speed = elapsed > 0 ? downloadedBytes / elapsed : 0;
                                    double remainingSec = (speed > 0 && totalBytes > 0) ? (totalBytes - downloadedBytes) / speed : -1;

                                    string downloadedMB = (downloadedBytes / 1048576.0).ToString("0.0");
                                    string totalMB = totalBytes > 0 ? (totalBytes / 1048576.0).ToString("0.0") : "?";
                                    string speedStr = FormatSpeed(speed);
                                    string etaStr = FormatETA(remainingSec);

                                    string js = $"window.onUpdateProgress&&window.onUpdateProgress({{percent:{percent},downloaded:'{downloadedMB}',total:'{totalMB}',speed:'{speedStr}',eta:'{etaStr}'}})";
                                    _w.Dispatcher.BeginInvoke(new Action(async () =>
                                    {
                                        try { await _w.webView.ExecuteScriptAsync(js); } catch { }
                                    }));
                                }
                            }
                        }
                    }
                    finally
                    {
                        response?.Dispose();
                        activeClient?.Dispose();
                    }

                    // حفظ الإصدار الجديد محلياً قبل تشغيل المثبّت
                    if (!string.IsNullOrEmpty(version))
                    {
                        _w.Dispatcher.Invoke(() => _w.SetInstalledVersion(version));
                    }

                    // إبلاغ JS بالانتهاء
                    string doneJs = "window.onUpdateComplete&&window.onUpdateComplete({success:true})";
                    _w.Dispatcher.BeginInvoke(new Action(async () =>
                    {
                        try { await _w.webView.ExecuteScriptAsync(doneJs); } catch { }
                    }));
                }
                catch (Exception ex)
                {
                    string errJs = $"window.onUpdateComplete&&window.onUpdateComplete({{success:false,error:{Newtonsoft.Json.JsonConvert.SerializeObject(ex.Message)}}})";
                    _w.Dispatcher.BeginInvoke(new Action(async () =>
                    {
                        try { await _w.webView.ExecuteScriptAsync(errJs); } catch { }
                    }));
                }
            });

            // نرجع فوراً — التحميل يكمل بالخلفية والـ progress يوصل عبر JS callbacks
            return Newtonsoft.Json.JsonConvert.SerializeObject(new { started = true });
        }

        private static string FormatSpeed(double bytesPerSec)
        {
            if (bytesPerSec <= 0) return "...";
            if (bytesPerSec >= 1048576) return (bytesPerSec / 1048576.0).ToString("0.0") + " MB/s";
            if (bytesPerSec >= 1024) return (bytesPerSec / 1024.0).ToString("0") + " KB/s";
            return bytesPerSec.ToString("0") + " B/s";
        }

        private static string FormatETA(double seconds)
        {
            if (seconds < 0) return "غير معروف";
            if (seconds < 60) return ((int)seconds) + " ثانية";
            if (seconds < 3600) return ((int)(seconds / 60)) + " دقيقة " + ((int)(seconds % 60)) + " ثانية";
            return ((int)(seconds / 3600)) + " ساعة " + ((int)((seconds % 3600) / 60)) + " دقيقة";
        }

        // مقارنة إصدارات (1.2.3 > 1.2.0)
        private static bool IsNewerVersion(string remote, string current)
        {
            try
            {
                var rv = remote.Split('.').Select(int.Parse).ToArray();
                var cv = current.Split('.').Select(int.Parse).ToArray();
                int len = Math.Max(rv.Length, cv.Length);
                for (int i = 0; i < len; i++)
                {
                    int r = i < rv.Length ? rv[i] : 0;
                    int c = i < cv.Length ? cv[i] : 0;
                    if (r > c) return true;
                    if (r < c) return false;
                }
                return false;
            }
            catch
            {
                return remote != current;
            }
        }
    }
}
