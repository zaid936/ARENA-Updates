using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Threading;
using Microsoft.Web.WebView2.Core;
using Newtonsoft.Json;

namespace ARENA
{
    public partial class MainWindow : Window
    {
        // ═══════════════════════════════════════════════════════════════════════
        //  Win32 API
        // ═══════════════════════════════════════════════════════════════════════
        [DllImport("user32.dll")] static extern bool   SetForegroundWindow(IntPtr h);
        [DllImport("user32.dll")] static extern IntPtr  GetForegroundWindow();
        [DllImport("user32.dll")] static extern short   GetAsyncKeyState(int vk);
        [DllImport("user32.dll")] static extern IntPtr  SetWindowsHookEx(int id, LowLevelKeyboardProc cb, IntPtr mod, uint tid);
        [DllImport("user32.dll")] static extern bool    UnhookWindowsHookEx(IntPtr h);
        [DllImport("user32.dll")] static extern IntPtr  CallNextHookEx(IntPtr h, int n, IntPtr w, IntPtr l);
        [DllImport("kernel32.dll")] static extern IntPtr GetModuleHandle(string? m);
        [DllImport("user32.dll")] static extern void    SwitchToThisWindow(IntPtr h, bool alt);
        [DllImport("user32.dll")] static extern bool    AttachThreadInput(uint a, uint b, bool f);
        [DllImport("user32.dll")] static extern uint    GetWindowThreadProcessId(IntPtr h, out uint pid);
        [DllImport("kernel32.dll")] static extern uint  GetCurrentThreadId();
        [DllImport("user32.dll")] static extern bool    ShowWindow(IntPtr h, int cmd);
        [DllImport("user32.dll")] static extern bool    BringWindowToTop(IntPtr h);
        [DllImport("user32.dll")] static extern bool    SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint f);
        [DllImport("user32.dll")] static extern bool    AllowSetForegroundWindow(uint pid);
        [DllImport("user32.dll")] static extern bool    RegisterHotKey(IntPtr h, int id, uint mod, uint vk);
        [DllImport("user32.dll")] static extern bool    UnregisterHotKey(IntPtr h, int id);
        [DllImport("user32.dll")] static extern IntPtr  FindWindow(string cls, string? title);
        [DllImport("user32.dll")] static extern bool    GetWindowRect(IntPtr h, out RECT r);
        [DllImport("user32.dll")] static extern int     GetSystemMetrics(int n);
        // خدعة Windows Foreground Lock — تجدد إذن سرقة الـ focus
        [DllImport("user32.dll")] static extern void    keybd_event(byte vk, byte scan, uint flags, int extra);
        // لإيجاد وإخفاء نافذة WebView2 الداخلية (HwndHost airspace fix)
        [DllImport("user32.dll")] static extern bool    EnumChildWindows(IntPtr parent, EnumChildProc cb, IntPtr param);
        [DllImport("user32.dll")] static extern int     GetClassName(IntPtr h, System.Text.StringBuilder buf, int max);
        delegate bool EnumChildProc(IntPtr hwnd, IntPtr param);

        [StructLayout(LayoutKind.Sequential)]
        struct RECT { public int L, T, R, B; }

        // HWND constants
        static readonly IntPtr HWND_TOP    = new(0);
        static readonly IntPtr HWND_BOTTOM = new(1);
        static readonly IntPtr HWND_TOPMOST    = new(-1);
        static readonly IntPtr HWND_NOTOPMOST  = new(-2);

        // ShowWindow
        const int SW_HIDE         = 0;
        const int SW_SHOW         = 5;
        const int SW_MAXIMIZE     = 3;
        const int SW_RESTORE      = 9;

        // SetWindowPos flags
        const uint SWP_NOMOVE     = 0x0002;
        const uint SWP_NOSIZE     = 0x0001;
        const uint SWP_SHOWWINDOW = 0x0040;
        const uint SWP_NOACTIVATE = 0x0010;
        const uint SWP_NOZORDER   = 0x0004;

        // Messages
        const int  WH_KEYBOARD_LL = 13;
        const int  WM_KEYDOWN     = 0x0100;
        const int  WM_SYSKEYDOWN  = 0x0104;
        const uint WM_SYSCOMMAND  = 0x0112;
        const int  SC_MINIMIZE    = 0xF020;
        const int  WM_HOTKEY      = 0x0312;

        // Hotkey
        const int  HOTKEY_ID      = 0x3001;
        const uint MOD_CTRL       = 0x0002;
        const uint MOD_SHIFT      = 0x0004;
        const uint MOD_NOREPEAT   = 0x4000;

        // VKeys
        const int VK_CTRL  = 0x11; const int VK_ALT   = 0x12; const int VK_SHIFT = 0x10;
        const int VK_LWIN  = 0x5B; const int VK_RWIN  = 0x5C; const int VK_TAB   = 0x09;
        const int VK_ESC   = 0x1B; const int VK_F4    = 0x73; const int VK_DEL   = 0x2E;
        const int VK_F1    = 0x70; const int VK_F12   = 0x7B; const int VK_Z     = 0x5A;
        const int VK_H     = 0x48;

        bool IsCtrl()  => (GetAsyncKeyState(VK_CTRL)  & 0x8000) != 0;
        bool IsAlt()   => (GetAsyncKeyState(VK_ALT)   & 0x8000) != 0;
        bool IsShift() => (GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0;

        private delegate IntPtr LowLevelKeyboardProc(int n, IntPtr w, IntPtr l);
        [StructLayout(LayoutKind.Sequential)]
        struct KBDLLHOOKSTRUCT { public uint vk, scan, flags, time; public IntPtr extra; }

        // ═══════════════════════════════════════════════════════════════════════
        //  حقول الكلاس
        // ═══════════════════════════════════════════════════════════════════════
        LowLevelKeyboardProc? _kbProc;
        IntPtr  _hookId      = IntPtr.Zero;
        IntPtr  _myHwnd      = IntPtr.Zero;
        IntPtr  _taskbarHwnd = IntPtr.Zero;   // Shell_TrayWnd
        IntPtr  _startHwnd   = IntPtr.Zero;   // زر Start

        ArenaConfig     _config     = null!;
        ProcessManager  _procMan    = new();
        public DispatcherTimer _guardTimer = null!;
        ArenaHostObject _host       = null!;
        bool _webReady   = false;
        bool _allowExit  = false;
        bool _allowMin   = false;         // للمطوّر فقط (MinimizeToWindows)
        bool _gameMode   = false;         // true = لعبة شغّالة في المقدمة

        readonly DateTime[] _devTimes = new DateTime[4];
        int _devCount = 0;

        static readonly string AppsPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "ARENA", "apps.json");

        // ═══════════════════════════════════════════════════════════════════════
        //  بيانات للـ JS
        // ═══════════════════════════════════════════════════════════════════════
        public string GetRunningKeysJson() => JsonConvert.SerializeObject(_procMan.GetRunningKeys());
        public string GetAppsJson()        => File.Exists(AppsPath) ? File.ReadAllText(AppsPath) : "null";
        public void   SaveAppsJson(string j)
        { Directory.CreateDirectory(Path.GetDirectoryName(AppsPath)!); File.WriteAllText(AppsPath, j); }

        public string GetCurrentVersion() => _config.appVersion ?? "1.0.0";

        // ── إصدار التحديث المثبت محلياً ──
        public string GetInstalledVersion() => _config.installedVersion ?? "";
        public void SetInstalledVersion(string version)
        {
            _config.installedVersion = version;
            ConfigManager.Save(_config);
        }

        // ── إعداد ظهور زر التحديث بلوحة التحكم العادية ──
        public bool GetShowUpdateInNormalPanel() => _config.showUpdateInNormalPanel;
        public void SetShowUpdateInNormalPanel(bool value)
        {
            _config.showUpdateInNormalPanel = value;
            ConfigManager.Save(_config);
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  المُنشئ
        // ═══════════════════════════════════════════════════════════════════════
        public MainWindow()
        {
            InitializeComponent();
            _config       = ConfigManager.Load();
            WindowStyle   = WindowStyle.None;
            WindowState   = WindowState.Maximized;
            Topmost       = true;
            ResizeMode    = ResizeMode.NoResize;
            ShowInTaskbar = false;

            _kbProc = KbHook;
            using var proc = Process.GetCurrentProcess();
            using var mod  = proc.MainModule!;
            _hookId = SetWindowsHookEx(WH_KEYBOARD_LL, _kbProc, GetModuleHandle(mod.ModuleName!), 0);

            Loaded += OnLoaded;
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  Keyboard Hook
        // ═══════════════════════════════════════════════════════════════════════
        IntPtr KbHook(int n, IntPtr w, IntPtr l)
        {
            if (n >= 0 && (w == (IntPtr)WM_KEYDOWN || w == (IntPtr)WM_SYSKEYDOWN))
            {
                var ks = Marshal.PtrToStructure<KBDLLHOOKSTRUCT>(l);
                uint vk = ks.vk;
                bool ctrl  = IsCtrl();
                bool shift = IsShift();
                bool alt   = IsAlt();

                // ═══ اختصارات ARENA أولاً — قبل أي حجب ═══

                // Ctrl+Shift+H → الرجوع لـ ARENA
                if (vk == VK_H && ctrl && shift)
                {
                    Dispatcher.BeginInvoke(new Action(async () => await ReturnToArenaAsync()));
                    return (IntPtr)1;
                }
                // Ctrl+Shift+Z × 4 → القائمة السرية
                if (vk == VK_Z && ctrl && shift)
                {
                    Dispatcher.BeginInvoke(new Action(HandleDevKey));
                    return (IntPtr)1;
                }

                // ═══ اختصارات محجوبة ═══
                if (vk == VK_LWIN || vk == VK_RWIN)            return (IntPtr)1;
                if (vk == VK_F4  && alt)                         return (IntPtr)1;
                if (vk == VK_TAB && alt)                         return (IntPtr)1;
                if (vk == VK_ESC && ctrl)                        return (IntPtr)1;
                if (vk == VK_DEL && ctrl && alt)                 return (IntPtr)1;
                if (vk == VK_ESC && ctrl && shift)               return (IntPtr)1;
                if (vk >= VK_F1  && vk <= VK_F12 && vk != VK_F12)  return (IntPtr)1;  // F12 مسموح للـ DevTools
            }
            return CallNextHookEx(_hookId, n, w, l);
        }

        async void HandleDevKey()
        {
            var now = DateTime.Now;
            if (_devCount > 0 && (now - _devTimes[_devCount - 1]).TotalSeconds > 3) _devCount = 0;
            if (_devCount < 4) _devTimes[_devCount] = now;
            if (++_devCount >= 4)
            {
                _devCount = 0;
                _guardTimer.Stop();
                _gameMode = false;
                _procMan.MinimizeAllGames();
                await Task.Delay(150);

                Topmost = true;
                SetWindowPos(_myHwnd, HWND_TOPMOST, 0, 0,
                    GetSystemMetrics(0), GetSystemMetrics(1), SWP_SHOWWINDOW);
                SetForegroundWindow(_myHwnd);
                Activate(); Focus();
                await Task.Delay(100);
                webView?.Focus();
                await Task.Delay(100);

                // افتح نافذة كلمة المرور بالـ JS
                await SendJS("window.onArenaMessage&&window.onArenaMessage({type:'OPEN_PASSWORD_MODAL'})");
                // الـ timer يرجع لمن الـ JS يرسل ADMIN_CLOSED
            }
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  OnLoaded
        // ═══════════════════════════════════════════════════════════════════════
        async void OnLoaded(object s, RoutedEventArgs e)
        {
            _myHwnd      = new WindowInteropHelper(this).Handle;
            _taskbarHwnd = FindWindow("Shell_TrayWnd", null);
            _startHwnd   = FindWindow("Button", null);

            // ── الحل 3: إلغاء Windows Foreground Lock من أول لحظة ──────────
            // يضبط Registry + SystemParametersInfo حتى أي نافذة تقدر تسرق الـ focus
            ProcessManager.ApplyForegroundUnlock();

            // أخفِ شريط Windows من البداية
            HideWinTaskbar();

            // لما لعبة تُغلق — نبلّغ الـ JS بس ما نرجع ARENA تلقائياً
            // المستخدم لازم يدوس Ctrl+Shift+H أو Ctrl+Alt+H بإيده
            _procMan.OnGameClosed += key => Dispatcher.Invoke(() =>
            {
                _ = SendJS($"window.onArenaMessage&&window.onArenaMessage({{type:'GAME_CLOSED',key:{JsonConvert.SerializeObject(key)}}})");
                // ما نرجع ARENA — نخليها تحت حتى المستخدم يدوس الاختصار
            });

            // Guard timer: لو ARENA المفروض أمام الكل → تأكد
            _guardTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(500) };
            _guardTimer.Tick += (_, _) =>
            {
                if (_gameMode || _allowMin) return;
                var fg = GetForegroundWindow();
                if (fg != _myHwnd && fg != IntPtr.Zero)
                {
                    // تأكد أن النافذة الأمامية ليست نافذة ملفات (OpenFileDialog)
                    // حتى ما يتعارض مع اختيار الملفات من لوحة التحكم
                    Activate(); Focus();
                }
                HideWinTaskbar();
            };
            _guardTimer.Start();

            CreateDesktopShortcut();
            DisableOtherStartups();
            await InitWebView();
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  Taskbar Windows
        // ═══════════════════════════════════════════════════════════════════════
        void HideWinTaskbar()
        {
            if (_taskbarHwnd != IntPtr.Zero) ShowWindow(_taskbarHwnd, SW_HIDE);
            if (_startHwnd   != IntPtr.Zero) ShowWindow(_startHwnd,   SW_HIDE);
            // شريط المهام الثانوي (شاشات متعددة)
            IntPtr secTray = FindWindow("Shell_SecondaryTrayWnd", null);
            if (secTray != IntPtr.Zero) ShowWindow(secTray, SW_HIDE);
            // Windows 11 — نافذة الـ TaskBar الجديدة
            IntPtr w11Bar = FindWindow("XamlExplorerHostIslandWindow", null);
            if (w11Bar  != IntPtr.Zero) ShowWindow(w11Bar,  SW_HIDE);
        }
        void ShowWinTaskbar()
        {
            if (_taskbarHwnd != IntPtr.Zero) ShowWindow(_taskbarHwnd, SW_SHOW);
            if (_startHwnd   != IntPtr.Zero) ShowWindow(_startHwnd,   SW_SHOW);
            // شريط المهام الثانوي (شاشات متعددة)
            IntPtr secTray = FindWindow("Shell_SecondaryTrayWnd", null);
            if (secTray != IntPtr.Zero) ShowWindow(secTray, SW_SHOW);
            // Windows 11
            IntPtr w11Bar = FindWindow("XamlExplorerHostIslandWindow", null);
            if (w11Bar  != IntPtr.Zero) ShowWindow(w11Bar,  SW_SHOW);
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  ARENA تنزل تحت اللعبة — تضل fullscreen بس مو Topmost
        //  المستخدم ما يكدر يوصل للديسكتوب لأن ARENA تغطي كل الشاشة
        // ═══════════════════════════════════════════════════════════════════════
        void PushArenaToBack()
        {
            _gameMode = true;
            _guardTimer.Stop();
            Topmost = false;

            // كسر Windows Foreground Lock
            keybd_event(0, 0, 0, 0);
            keybd_event(0, 0, 2, 0);
            AllowSetForegroundWindow(0xFFFFFFFF);

            // ARENA تضل بمكانها fullscreen بس تنزل بالـ z-order
            // ما نحركها خارج الشاشة — تضل تغطي الديسكتوب
            int sw = GetSystemMetrics(0);
            int sh = GetSystemMetrics(1);
            SetWindowPos(_myHwnd, HWND_BOTTOM,
                0, 0, sw, sh,
                SWP_NOACTIVATE);
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  إرجاع ARENA للمقدمة
        // ═══════════════════════════════════════════════════════════════════════
        void ShowArenaOnTop()
        {
            _gameMode = false;
            Topmost   = true;

            int sw = GetSystemMetrics(0);
            int sh = GetSystemMetrics(1);
            ShowWindow(_myHwnd, SW_RESTORE);
            SetWindowPos(_myHwnd, HWND_TOPMOST,
                0, 0, sw, sh,
                SWP_SHOWWINDOW);

            uint fgTid = GetWindowThreadProcessId(GetForegroundWindow(), out _);
            uint myTid = GetCurrentThreadId();
            bool att   = false;
            if (fgTid != 0 && fgTid != myTid) att = AttachThreadInput(fgTid, myTid, true);
            try
            {
                keybd_event(0, 0, 0, 0);
                keybd_event(0, 0, 2, 0);
                AllowSetForegroundWindow(0xFFFFFFFF);
                SetForegroundWindow(_myHwnd);
                SwitchToThisWindow(_myHwnd, true);
                Activate(); Focus(); webView?.Focus();
            }
            finally { if (att) AttachThreadInput(fgTid, myTid, false); }

            if (!_guardTimer.IsEnabled) _guardTimer.Start();
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  Ctrl+Shift+H → الرجوع لـ ARENA
        // ═══════════════════════════════════════════════════════════════════════
        bool _returning = false;
        async Task ReturnToArenaAsync()
        {
            if (_returning) return;
            _returning = true;
            try
            {
                _guardTimer.Stop();
                _gameMode = false;

                // صغّر كل الألعاب
                _procMan.MinimizeAllGames();
                await Task.Delay(200);

                // ارجع ARENA للمقدمة بالقوة
                Topmost = true;
                int sw = GetSystemMetrics(0);
                int sh = GetSystemMetrics(1);
                ShowWindow(_myHwnd, SW_RESTORE);
                SetWindowPos(_myHwnd, HWND_TOPMOST, 0, 0, sw, sh, SWP_SHOWWINDOW);

                keybd_event(0, 0, 0, 0);
                keybd_event(0, 0, 2, 0);
                AllowSetForegroundWindow(0xFFFFFFFF);
                SetForegroundWindow(_myHwnd);
                BringWindowToTop(_myHwnd);
                SwitchToThisWindow(_myHwnd, true);
                Activate(); Focus();
                await Task.Delay(100);
                webView?.Focus();
                await Task.Delay(300);

                await SendJS("window.onArenaMessage&&window.onArenaMessage({type:'BRING_TO_FRONT'})");

                _guardTimer.Start();
            }
            finally { _returning = false; }
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  تشغيل اللعبة
        // ═══════════════════════════════════════════════════════════════════════
        public void LaunchGame(string key, string path, string type)
        {
            if (type == "web")
            {
                _ = SendJS($"window.openEmbedded&&window.openEmbedded({JsonConvert.SerializeObject(path)},{JsonConvert.SerializeObject(key)})");
                return;
            }

            if (_procMan.IsRunning(key)) { FocusGame(key); return; }

            try
            {
                HideWinTaskbar();

                // نزّل ARENA — تضل fullscreen تغطي الديسكتوب بس تحت التطبيق المختار
                PushArenaToBack();

                // شغّل اللعبة
                _procMan.LaunchGame(key, path, type);

                // بعد التشغيل — ارفع بس هالتطبيق فوق ARENA
                bool isUri = type == "uri" || path.StartsWith("steam://", StringComparison.OrdinalIgnoreCase)
                             || path.StartsWith("discord://", StringComparison.OrdinalIgnoreCase);
                bool isLnk = path.EndsWith(".lnk", StringComparison.OrdinalIgnoreCase);
                if (!isUri && !isLnk)
                    _ = _procMan.FocusAfterLaunchAsync(key);
            }
            catch (Exception ex)
            {
                _gameMode = false;
                Topmost   = true;
                ShowArenaOnTop();
                _ = SendJS($"window.showGameError&&window.showGameError({JsonConvert.SerializeObject(ex.Message)})");
            }
        }

        public void FocusGame(string key)
        {
            if (!_procMan.IsRunning(key)) return;

            // ARENA تنزل تحت — بس التطبيق المختار يطلع فوقها
            _gameMode = true;
            _guardTimer.Stop();
            Topmost = false;

            // ما نستخدم HWND_BOTTOM — نخلي ARENA بس مو Topmost
            // واللعبة تطلع فوقها
            keybd_event(0, 0, 0, 0);
            keybd_event(0, 0, 2, 0);
            AllowSetForegroundWindow(0xFFFFFFFF);

            Dispatcher.InvokeAsync(async () =>
            {
                await Task.Delay(150);
                _procMan.FocusGame(key);
            });
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  WebView2
        // ═══════════════════════════════════════════════════════════════════════
        async Task InitWebView()
        {
            try
            {
                string udDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "WebView2Data");
                Directory.CreateDirectory(udDir);
                var env = await CoreWebView2Environment.CreateAsync(null, udDir,
                    new CoreWebView2EnvironmentOptions
                    { AdditionalBrowserArguments = "--autoplay-policy=no-user-gesture-required" });
                await webView.EnsureCoreWebView2Async(env);

                var s = webView.CoreWebView2.Settings;
                s.AreDevToolsEnabled               = true;  // مؤقت للفحص — اضغط F12
                s.AreDefaultContextMenusEnabled    = false;
                s.IsStatusBarEnabled               = false;
                s.IsZoomControlEnabled             = false;
                s.IsSwipeNavigationEnabled         = false;
                s.AreBrowserAcceleratorKeysEnabled = true;  // مؤقت للـ F12

                _host = new ArenaHostObject(this);
                webView.CoreWebView2.AddHostObjectToScript("arenaHost", _host);
                webView.CoreWebView2.WebMessageReceived += OnJsMsg;

                string wwwroot = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "wwwroot");
                if (!Directory.Exists(wwwroot))
                { MessageBox.Show($"wwwroot غير موجود:\n{wwwroot}", "ARENA"); return; }

                webView.CoreWebView2.SetVirtualHostNameToFolderMapping(
                    "arena.app", wwwroot, CoreWebView2HostResourceAccessKind.Allow);

                webView.CoreWebView2.NavigationCompleted += async (_, a) =>
                {
                    if (!a.IsSuccess) return;
                    _webReady = true;
                    await webView.ExecuteScriptAsync(@"
                        (async()=>{try{window.arenaHost=await window.chrome.webview.hostObjects.arenaHost;}catch(e){console.error(e);}})();
                    ");
                    await Task.Delay(500);
                    // أعد تحميل الألعاب بعد ما arenaHost صار جاهز
                    await SendJS("if(typeof loadApps==='function')loadApps()");
                    await PushConfig();
                    // تأكد أن ARENA يظهر في المقدمة بعد تحميل الصفحة
                    Dispatcher.Invoke(() =>
                    {
                        HideWinTaskbar();
                        ShowArenaOnTop();
                    });
                };
                webView.CoreWebView2.Navigate("https://arena.app/index.html");
            }
            catch (Exception ex)
            { MessageBox.Show($"خطأ WebView2:\n{ex.Message}\n\nثبّت Microsoft Edge WebView2 Runtime.", "ARENA"); }
        }

        async Task PushConfig()
        {
            var c = new { cloudEnabled = _config.cloudEnabled,
                          pcName = string.IsNullOrEmpty(_config.pcName) ? Environment.MachineName : _config.pcName };
            await SendJS($"window.onArenaConfig&&window.onArenaConfig({JsonConvert.SerializeObject(c)})");
        }

        async Task SendJS(string script)
        {
            if (!_webReady) return;
            try { await webView.ExecuteScriptAsync(script); }
            catch (Exception ex) { Debug.WriteLine($"[JS] {ex.Message}"); }
        }

        void OnJsMsg(object? s, CoreWebView2WebMessageReceivedEventArgs e)
        {
            try
            {
                var msg = JsonConvert.DeserializeObject<Dictionary<string, object>>(e.TryGetWebMessageAsString());
                if (msg == null) return;
                string type = msg.GetValueOrDefault("type")?.ToString() ?? "";
                if (type == "POWER" && msg.ContainsKey("command"))
                    Dispatcher.Invoke(() => ExecutePower(msg["command"].ToString()!));
                if (type == "ADMIN_CLOSED")
                    Dispatcher.BeginInvoke(new Action(() => { if (!_guardTimer.IsEnabled) _guardTimer.Start(); }));
            }
            catch { }
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  API للـ JS / ArenaHostObject
        // ═══════════════════════════════════════════════════════════════════════
        public string GetRunningStatusJson() => JsonConvert.SerializeObject(_procMan.GetRunningStatus());
        public void   KillAllGames()         => _procMan.KillAllGames();
        public void   KillGame(string key)   => _procMan.KillGame(key);

        // للتوافق
        public void CloseEmbed() { }
        public void FocusEmbed() { }

        public bool   VerifyAdminPassword(string h) => _config.adminPassword == h;
        public void   SetAdminPassword(string h)    { _config.adminPassword = h; ConfigManager.Save(_config); }
        public string GetConfigJson()               => JsonConvert.SerializeObject(_config);
        public string GetPcName()                   => string.IsNullOrEmpty(_config.pcName) ? Environment.MachineName : _config.pcName;

        public void SaveConfigFromJson(string json)
        {
            var u = JsonConvert.DeserializeObject<ArenaConfig>(json);
            if (u != null) { _config = u; ConfigManager.Save(_config); }
        }

        public void ExecutePower(string cmd)
        {
            _procMan.KillAllGames();
            if (cmd == "SHUTDOWN") Process.Start("shutdown", "/s /t 10");
            if (cmd == "RESTART")  Process.Start("shutdown", "/r /t 10");
            _ = SendJS("window.resetPowerField&&window.resetPowerField()");
        }

        public void SetCloudMode(bool on, string name)
        { _config.cloudEnabled = on; _config.pcName = name; ConfigManager.Save(_config); }

        // المطوّر فقط: العودة لـ Windows مؤقتاً
        public void MinimizeToWindows()
        {
            _ = SendJS("document.getElementById('adminPanel')?.classList.remove('visible')");
            _allowMin   = true;
            _gameMode   = true;
            _guardTimer.Stop();
            ShowWinTaskbar();
            Topmost     = false;
            WindowState = WindowState.Minimized;
            var t = new DispatcherTimer { Interval = TimeSpan.FromSeconds(30) };
            t.Tick += (s, _) =>
            {
                ((DispatcherTimer)s!).Stop();
                _allowMin   = false;
                _gameMode   = false;
                HideWinTaskbar();
                WindowState = WindowState.Maximized;
                ShowArenaOnTop();
                _guardTimer.Start();
            };
            t.Start();
        }

        public void ExitApplication()
        {
            _allowExit = true;
            ShowWinTaskbar();   // أرجع الشريط عند الإغلاق
            if (_hookId != IntPtr.Zero) { UnhookWindowsHookEx(_hookId); _hookId = IntPtr.Zero; }
            _guardTimer?.Stop();
            _procMan.KillAllGames();
            Application.Current.Shutdown();
        }

        public string PickImageFile()
        {
            _guardTimer.Stop();
            Topmost = false;
            try
            {
                var d = new Microsoft.Win32.OpenFileDialog
                    { Filter = "صور|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.webp", Title = "اختر صورة الغلاف" };
                if (d.ShowDialog(this) != true) return "";
                string dir  = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "wwwroot", "covers");
                Directory.CreateDirectory(dir);
                string dest = Path.Combine(dir, Path.GetFileName(d.FileName));
                File.Copy(d.FileName, dest, true);
                return "covers/" + Path.GetFileName(d.FileName);
            }
            finally
            {
                Topmost = true;
                _guardTimer.Start();
            }
        }

        public string PickExeFile()
        {
            _guardTimer.Stop();
            Topmost = false;
            try
            {
                var d = new Microsoft.Win32.OpenFileDialog
                    { Filter = "ملفات تنفيذية|*.exe;*.lnk", Title = "اختر ملف اللعبة" };
                return d.ShowDialog(this) == true ? d.FileName : "";
            }
            finally
            {
                Topmost = true;
                _guardTimer.Start();
            }
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  قفل النافذة
        // ═══════════════════════════════════════════════════════════════════════
        protected override void OnClosing(CancelEventArgs e)
        { if (!_allowExit) e.Cancel = true; else base.OnClosing(e); }

        protected override void OnStateChanged(EventArgs e)
        {
            // امنع التصغير إلا في حالة _allowMin (المطوّر)
            if (!_allowExit && !_allowMin && WindowState == WindowState.Minimized)
                WindowState = WindowState.Maximized;
            base.OnStateChanged(e);
        }

        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            HwndSource.FromHwnd(_myHwnd == IntPtr.Zero
                ? (_myHwnd = new WindowInteropHelper(this).Handle)
                : _myHwnd)?.AddHook(WndProc);
            // سجّل Ctrl+Alt+H فقط
            const uint MOD_ALT = 0x0001;
            UnregisterHotKey(_myHwnd, HOTKEY_ID);
            RegisterHotKey(_myHwnd, HOTKEY_ID, MOD_CTRL | MOD_ALT | MOD_NOREPEAT, (uint)VK_H);
        }

        IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (msg == WM_HOTKEY && wParam.ToInt32() == HOTKEY_ID)
            {
                handled = true;
                Dispatcher.InvokeAsync(async () => await ReturnToArenaAsync());
            }
            // امنع Minimize عبر WM_SYSCOMMAND
            if (!_allowExit && !_allowMin && msg == (int)WM_SYSCOMMAND
                && (int)(wParam.ToInt64() & 0xFFF0) == SC_MINIMIZE)
                handled = true;
            return IntPtr.Zero;
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  إيقاف تطبيقات Startup الأخرى — ARENA فقط تشتغل عند بدء النظام
        // ═══════════════════════════════════════════════════════════════════════
        static void DisableOtherStartups()
        {
            try
            {
                // إيقاف تطبيقات Startup من الـ Registry
                string[] runKeys = {
                    @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
                    @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run"
                };
                string myExe = System.Reflection.Assembly.GetExecutingAssembly().Location.Replace(".dll", ".exe");
                string myName = Path.GetFileNameWithoutExtension(myExe).ToLower();

                foreach (var keyPath in runKeys)
                {
                    using var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(keyPath, writable: true);
                    if (key == null) continue;
                    foreach (var name in key.GetValueNames())
                    {
                        if (name.ToLower().Contains("arena")) continue; // ما نوقف ARENA نفسها
                        string? val = key.GetValue(name)?.ToString()?.ToLower() ?? "";
                        if (val.Contains(myName)) continue;
                        try { key.DeleteValue(name); } catch { }
                    }
                }

                // نفس الشي لـ HKLM
                foreach (var keyPath in runKeys)
                {
                    try
                    {
                        using var key = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(keyPath, writable: true);
                        if (key == null) continue;
                        foreach (var name in key.GetValueNames())
                        {
                            if (name.ToLower().Contains("arena")) continue;
                            string? val = key.GetValue(name)?.ToString()?.ToLower() ?? "";
                            if (val.Contains(myName)) continue;
                            try { key.DeleteValue(name); } catch { }
                        }
                    }
                    catch { } // HKLM يحتاج Admin
                }

                // إيقاف تطبيقات Startup folder
                string startupFolder = Environment.GetFolderPath(Environment.SpecialFolder.Startup);
                if (Directory.Exists(startupFolder))
                {
                    foreach (var file in Directory.GetFiles(startupFolder))
                    {
                        string fn = Path.GetFileName(file).ToLower();
                        if (fn.Contains("arena")) continue;
                        try { File.Delete(file); } catch { }
                    }
                }
            }
            catch { }
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  اختصار سطح المكتب
        // ═══════════════════════════════════════════════════════════════════════
        public static void CreateDesktopShortcut()
        {
            try
            {
                string lnk = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "ARENA.lnk");
                string exe = System.Reflection.Assembly.GetExecutingAssembly().Location.Replace(".dll", ".exe");
                Type? t = Type.GetTypeFromProgID("WScript.Shell"); if (t == null) return;
                dynamic sh = Activator.CreateInstance(t)!;
                dynamic sc = sh.CreateShortcut(lnk);
                sc.TargetPath = exe; sc.WorkingDirectory = AppDomain.CurrentDomain.BaseDirectory;
                sc.Description = "الرجوع إلى ARENA Gaming Center"; sc.Save();
            }
            catch { }
        }
    }
}
