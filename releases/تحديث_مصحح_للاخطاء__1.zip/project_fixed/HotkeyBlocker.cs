using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace ARENA
{
    public class HotkeyBlocker : IDisposable
    {
        private const int WH_KEYBOARD_LL = 13;
        private const int WM_KEYDOWN     = 0x0100;
        private const int WM_SYSKEYDOWN  = 0x0104;

        private const uint VK_LWIN    = 0x5B;
        private const uint VK_RWIN    = 0x5C;
        private const uint VK_TAB     = 0x09;
        private const uint VK_ESCAPE  = 0x1B;
        private const uint VK_F4      = 0x73;
        private const uint VK_DELETE  = 0x2E;
        private const uint VK_F1      = 0x70;
        private const uint VK_F12     = 0x7B;
        private const uint VK_CONTROL = 0x11;
        private const uint VK_MENU    = 0x12;   // Alt
        private const uint VK_SHIFT   = 0x10;
        private const uint VK_H       = 0x48;
        private const uint VK_Z       = 0x5A;

        private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
        private LowLevelKeyboardProc _proc;
        private IntPtr _hookID = IntPtr.Zero;

        // عدّاد Ctrl+Alt+Z
        private int      _zCount = 0;
        private DateTime _lastZ  = DateTime.MinValue;

        public event Action<string>? TamperAttempt;

        // ─── Events جديدة يستقبلها MainWindow ────────────────────
        public event Action? BringToFrontRequested;   // Ctrl+Alt+H
        public event Action? SecretMenuRequested;     // Ctrl+Alt+Z ×4

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(uint vKey);

        [StructLayout(LayoutKind.Sequential)]
        private struct KBDLLHOOKSTRUCT
        {
            public uint vkCode;
            public uint scanCode;
            public uint flags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        public HotkeyBlocker()
        {
            _proc   = HookCallback;
            _hookID = SetHook(_proc);
        }

        private IntPtr SetHook(LowLevelKeyboardProc proc)
        {
            using var curProcess = Process.GetCurrentProcess();
            using var curModule  = curProcess.MainModule!;
            return SetWindowsHookEx(WH_KEYBOARD_LL, proc, GetModuleHandle(curModule.ModuleName!), 0);
        }

        private bool IsKeyDown(uint vk) => (GetAsyncKeyState(vk) & 0x8000) != 0;

        private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0)
            {
                var hookStruct = Marshal.PtrToStructure<KBDLLHOOKSTRUCT>(lParam);
                uint vk     = hookStruct.vkCode;
                bool isDown = wParam == (IntPtr)WM_KEYDOWN || wParam == (IntPtr)WM_SYSKEYDOWN;

                if (isDown)
                {
                    bool ctrl = IsKeyDown(VK_CONTROL);
                    bool alt  = IsKeyDown(VK_MENU);

                    // ── Ctrl+Alt+H → BringToFront ─────────────────────────
                    if (ctrl && alt && vk == VK_H)
                    {
                        System.Threading.ThreadPool.QueueUserWorkItem(_ => BringToFrontRequested?.Invoke());
                        return new IntPtr(1);
                    }

                    // ── Ctrl+Alt+Z ×4 → Secret Menu ───────────────────────
                    if (ctrl && alt && vk == VK_Z)
                    {
                        if ((DateTime.Now - _lastZ).TotalSeconds > 3) _zCount = 0;
                        _lastZ = DateTime.Now;
                        if (++_zCount >= 4)
                        {
                            _zCount = 0;
                            System.Threading.ThreadPool.QueueUserWorkItem(_ => SecretMenuRequested?.Invoke());
                        }
                        return new IntPtr(1);
                    }

                    // ── Block system hotkeys ───────────────────────────────
                    if (ShouldBlock(vk, ctrl, alt))
                    {
                        TamperAttempt?.Invoke(GetKeyDescription(vk));
                        return new IntPtr(1);
                    }
                }
            }
            return CallNextHookEx(_hookID, nCode, wParam, lParam);
        }

        private bool ShouldBlock(uint vk, bool ctrl, bool alt)
        {
            bool shift = IsKeyDown(VK_SHIFT);

            if (vk == VK_LWIN || vk == VK_RWIN)        return true;
            if (alt  && vk == VK_F4)                    return true;
            if (alt  && vk == VK_TAB)                   return true;
            if (ctrl && vk == VK_ESCAPE)                return true;
            if (ctrl && alt && vk == VK_DELETE)         return true;
            if (ctrl && shift && vk == VK_ESCAPE)       return true;
            if (vk >= VK_F1 && vk <= VK_F12)            return true;

            return false;
        }

        private string GetKeyDescription(uint vk)
        {
            bool ctrl  = IsKeyDown(VK_CONTROL);
            bool alt   = IsKeyDown(VK_MENU);
            bool shift = IsKeyDown(VK_SHIFT);

            string mods = (ctrl ? "Ctrl+" : "") + (alt ? "Alt+" : "") + (shift ? "Shift+" : "");
            string key = vk switch
            {
                VK_LWIN   => "LWin",
                VK_RWIN   => "RWin",
                VK_F4     => "F4",
                VK_TAB    => "Tab",
                VK_ESCAPE => "Escape",
                VK_DELETE => "Delete",
                _ when vk >= VK_F1 && vk <= VK_F12 => $"F{vk - VK_F1 + 1}",
                _ => $"VK_{vk:X2}"
            };
            return mods + key;
        }

        public void Dispose()
        {
            if (_hookID != IntPtr.Zero)
            {
                UnhookWindowsHookEx(_hookID);
                _hookID = IntPtr.Zero;
            }
        }
    }
}
