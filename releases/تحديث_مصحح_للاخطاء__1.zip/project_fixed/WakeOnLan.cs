using System;
using System.Net;
using System.Net.Sockets;

namespace ARENA
{
    public static class WakeOnLan
    {
        /// <summary>
        /// Sends a Wake-on-LAN magic packet to the given MAC address.
        /// macAddress format: "AABBCCDDEEFF" or "AA:BB:CC:DD:EE:FF" or "AA-BB-CC-DD-EE-FF"
        /// </summary>
        public static void Send(string macAddress)
        {
            if (string.IsNullOrWhiteSpace(macAddress)) return;

            // Normalize MAC address
            string mac = macAddress.Replace(":", "").Replace("-", "").Replace(" ", "");
            if (mac.Length != 12)
            {
                System.Diagnostics.Debug.WriteLine($"[WakeOnLan] Invalid MAC: {macAddress}");
                return;
            }

            byte[] macBytes = new byte[6];
            for (int i = 0; i < 6; i++)
                macBytes[i] = Convert.ToByte(mac.Substring(i * 2, 2), 16);

            // Magic Packet: 6 bytes of 0xFF followed by 16 repetitions of MAC
            byte[] packet = new byte[6 + 16 * 6];
            for (int i = 0; i < 6; i++)
                packet[i] = 0xFF;
            for (int i = 1; i <= 16; i++)
                Buffer.BlockCopy(macBytes, 0, packet, i * 6, 6);

            try
            {
                using var client = new UdpClient();
                client.EnableBroadcast = true;
                client.Send(packet, packet.Length, new IPEndPoint(IPAddress.Broadcast, 9));
                System.Diagnostics.Debug.WriteLine($"[WakeOnLan] Sent magic packet to {macAddress}");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[WakeOnLan] Error: {ex.Message}");
            }
        }
    }
}
