[Setup]
AppName=ARENA Gaming Launcher
AppVersion=1.0
AppPublisher=ARENA
DefaultDirName=C:\ARENA
DefaultGroupName=ARENA
OutputBaseFilename=ARENA_Setup
Compression=lzma2
SolidCompression=yes
DisableDirPage=yes
DisableProgramGroupPage=yes
PrivilegesRequired=admin
WizardStyle=modern
SetupIconFile=arena.ico
UninstallDisplayIcon={app}\ARENA.exe

[Files]
Source: "publish\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion
Source: "arena.ico"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{commondesktop}\ARENA"; Filename: "{app}\ARENA.exe"; IconFilename: "{app}\arena.ico"
Name: "{group}\ARENA"; Filename: "{app}\ARENA.exe"; IconFilename: "{app}\arena.ico"

[Registry]
Root: HKLM; Subkey: "SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"; ValueType: string; ValueName: "Shell"; ValueData: "{app}\ARENA.exe"
Root: HKCU; Subkey: "SOFTWARE\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "ARENA"; ValueData: "{app}\ARENA.exe"
Root: HKCU; Subkey: "SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"; ValueType: dword; ValueName: "DisableTaskMgr"; ValueData: 1
Root: HKCU; Subkey: "SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"; ValueType: dword; ValueName: "DisableLockWorkstation"; ValueData: 1

[Run]
Filename: "{app}\ARENA.exe"; Flags: postinstall nowait

[UninstallDelete]
Type: files; Name: "{app}\arena_config.json"

[Code]
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usPostUninstall then
  begin
    RegWriteStringValue(HKLM,
      'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon',
      'Shell', 'explorer.exe');
    RegDeleteValue(HKCU,
      'SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System',
      'DisableTaskMgr');
    RegDeleteValue(HKCU,
      'SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System',
      'DisableLockWorkstation');
  end;
end;

function WebView2Installed: Boolean;
var
  version: String;
begin
  Result := RegQueryStringValue(HKLM,
    'SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
    'pv', version) or
    RegQueryStringValue(HKLM,
    'SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
    'pv', version);
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
  begin
    if not WebView2Installed then
      MsgBox('Please install WebView2 Runtime from:' + #13#10 +
        'https://developer.microsoft.com/microsoft-edge/webview2/', mbInformation, MB_OK);
  end;
end;
