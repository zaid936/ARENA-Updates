// ═══════════════════════════════════════════════════════════
//  ARENA Gaming Launcher — main.js
//  Firebase Compat API (no ES modules — compatible with WebView2)
// ═══════════════════════════════════════════════════════════

// ─── Firebase Config ─────────────────────────────────────────
const firebaseConfig = {
  apiKey:            "AIzaSyDFUIJim1B1W6DuZCGEmjxBZmsdblM1l0Q",
  authDomain:        "arena-d2e1c.firebaseapp.com",
  projectId:         "arena-d2e1c",
  storageBucket:     "arena-d2e1c.firebasestorage.app",
  messagingSenderId: "274711377556",
  appId:             "1:274711377556:web:21d240f8a45807c6ade681",
  measurementId:     "G-5NZ5CWG40C",
  databaseURL:       "https://arena-d2e1c-default-rtdb.firebaseio.com"
};

// firebase object يجي من الـ CDN scripts في index.html
let db   = null;
let rtdb = null;

function initFirebaseIfNeeded() {
  if (db) return;
  try {
    if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
    db   = firebase.firestore();
    rtdb = firebase.database();
  } catch(e) {
    console.error("[Firebase init]", e);
  }
}

// ─── Compat wrappers تطابق نفس API الأصلي ────────────────────
function doc(database, col, id)    { return database.collection(col).doc(id); }
function collection(database, col) { return database.collection(col); }

async function getDoc(docRef) {
  const snap = await docRef.get();
  return {
    exists: () => snap.exists,
    data:   () => snap.data(),
    id:     snap.id
  };
}

async function getDocs(colRef) {
  const snap = await colRef.get();
  return {
    empty: snap.empty,
    forEach: (fn) => snap.forEach(d => fn({ id: d.id, data: () => d.data() })),
    docs: snap.docs.map(d => ({ id: d.id, data: () => d.data() }))
  };
}

async function setDoc(docRef, data, opts) {
  if (opts && opts.merge) return docRef.set(data, { merge: true });
  return docRef.set(data);
}

async function updateDoc(docRef, data) {
  return docRef.update(data);
}

function onSnapshot(docRef, cb) {
  return docRef.onSnapshot(snap => cb({
    exists: () => snap.exists,
    data:   () => snap.data(),
    id:     snap.id
  }));
}

function query(colRef) { return colRef; }
function where(field, op, val) {
  return { field, op, val };
}

// RTDB wrappers
function ref(database, path)         { return database.ref(path); }
function onDisconnect(refObj)        { return refObj.onDisconnect(); }
async function set(refObj, data)     { return refObj.set(data); }

// ─── State ───────────────────────────────────────────────────
let pcName        = "PC-01";
let cloudEnabled  = false;
let hourlyRate    = 0;
let timerSeconds  = 0;
let savedSeconds  = 0;
let timerInterval = null;
let timeLimitSec  = 0;
let sessionActive = false;
let tamperCount   = 0;
let lastCommand   = "";
let warnShown     = false;
let apps          = [];
let categories    = [];
let currentCategory = "all";

// ─── DOM refs ────────────────────────────────────────────────
const waitingScreen   = () => document.getElementById("waitingScreen");
const mainInterface   = () => document.getElementById("mainInterface");
const loadingOverlay  = () => document.getElementById("loadingOverlay");
const loadingGameName = () => document.getElementById("loadingGameName");
const timeWarningEl   = () => document.getElementById("timeWarning");
const adminPanel      = () => document.getElementById("adminPanel");
const statusDot       = () => document.getElementById("statusDot");
const topTimer        = () => document.getElementById("topTimer");
const topCost         = () => document.getElementById("topCost");
const topPcName       = () => document.getElementById("topPcName");
const topClockTime    = () => document.getElementById("topClockTime");
const topClockDate    = () => document.getElementById("topClockDate");
const waitClock       = () => document.getElementById("waitClock");
const waitDate        = () => document.getElementById("waitDate");
const waitPcName      = () => document.getElementById("waitPcName");
const pausedBadge     = () => document.getElementById("pausedBadge");
const gameGrid        = () => document.getElementById("gameGrid");
const navTabs         = () => document.getElementById("navTabs");

// ─── Helpers: show/hide screens ──────────────────────────────
function showMainInterface() {
  const ws = waitingScreen();
  const mi = mainInterface();
  if (ws) ws.style.display = "none";
  if (mi) {
    mi.style.display = "flex"; mi.style.flexDirection = "column";
    mi.classList.remove("screen-fade-in");
    void mi.offsetWidth; // force reflow
    mi.classList.add("screen-fade-in");
  }
  const t = topTimer();
  const c = topCost();
  if (t) t.style.display = cloudEnabled ? "block" : "none";
  if (c) c.style.display = cloudEnabled ? "block" : "none";
  const cdWrap = document.getElementById("countdownWrap");
  if (cdWrap) cdWrap.style.display = (cloudEnabled && timeLimitSec > 0) ? "block" : "none";
}

function showWaitingScreen(paused = false) {
  const ws = waitingScreen();
  const mi = mainInterface();
  if (mi) mi.style.display = "none";
  if (ws) {
    ws.style.display        = "flex";
    ws.style.flexDirection  = "column";
    ws.style.alignItems     = "center";
    ws.style.justifyContent = "center";
  }
  const pb = pausedBadge();
  if (pb) pb.classList.toggle("visible", paused);
}

// ─── Entry point ─────────────────────────────────────────────
window.addEventListener("DOMContentLoaded", () => {
  setInterval(updateClock, 1000);
  updateClock();
  startBgCanvas();
  startParticles();
  loadApps();
  showMainInterface();

  let configReceived = false;
  window.onArenaConfig = function(cfg) {
    configReceived = true;
    applyConfig(cfg);
  };
  setTimeout(() => {
    if (!configReceived) {
      console.log("[ARENA] onArenaConfig timeout - staying in normal mode");
      applyConfig({ cloudEnabled: false, pcName: pcName });
    }
  }, 2000);

  window.addEventListener("offline", () => setOffline());
  window.addEventListener("online", async () => {
    setOnline();
    if (!cloudEnabled || !db) return;
    try {
      await updateDoc(doc(db, "stations", pcName), {
        "notifications.internet_lost": { time: new Date().toISOString(), pcName }
      });
    } catch(e) {}
  });
});

// ─── Apply config ─────────────────────────────────────────────
function applyConfig(cfg) {
  cloudEnabled = cfg.cloudEnabled || false;
  pcName       = cfg.pcName || pcName;

  const tp = topPcName(); const wp = waitPcName();
  if (tp) tp.textContent = pcName;
  if (wp) wp.textContent = pcName;

  initFirebaseIfNeeded();

  // أعد تحميل الألعاب — arenaHost الآن جاهز بعد ما C# سجّله
  loadApps();

  if (cloudEnabled) {
    showWaitingScreen();
    connectFirebase();
  } else {
    showMainInterface();
    connectFirebasePowerOnly();
  }
}

// ─── Messages from C# ────────────────────────────────────────
window.onArenaMessage = function(msg) {
  if (!msg) return;
  switch (msg.type) {
    case "BRING_TO_FRONT":
      showMainInterface();
      break;
    case "OPEN_PASSWORD_MODAL":
      openPasswordModal();
      break;
  }
};

// ─── طلع من اللعبة وارجع للواجهة ────────────────────────────
// Ctrl+Alt+H يستدعيها C# عبر onArenaMessage
// لكن لو اللعبة شغالة نعرضها بعد ما يغلق الادمن بانل

// ─── Firebase: Cloud Mode ────────────────────────────────────
async function connectFirebase() {
  try {
    initFirebaseIfNeeded();
    const stationRef = doc(db, "stations", pcName);
    await setDoc(stationRef, {
      "status.state":    "online",
      "status.lastSeen": new Date().toISOString()
    }, { merge: true });

    const presRef = ref(rtdb, `stations/${pcName}/status`);
    onDisconnect(presRef).set({ state: "offline", lastSeen: new Date().toISOString(), hadSession: sessionActive });
    await set(presRef, { state: "online", lastSeen: new Date().toISOString(), hadSession: false });

    setInterval(async () => {
      try { await updateDoc(stationRef, { "status.lastSeen": new Date().toISOString() }); } catch(e) {}
    }, 60000);

    onSnapshot(stationRef, async snap => {
      if (!snap.exists()) return;
      const data = snap.data();
      hourlyRate   = data.hourlyRate  || 0;
      timeLimitSec = data.timeLimit   || 0;

      const power = data.power || "ON";
      if (power !== "ON") {
        await updateDoc(stationRef, { power: "ON" });
        window.arenaHost.executePower(power);
        return;
      }

      const cmd = data.command || "";
      if (cmd && cmd !== lastCommand) {
        lastCommand = cmd;
        handleCommand(cmd, stationRef);
      }
    });

    watchAllStationsForWol();
    setOnline();
  } catch(e) {
    console.error("[Firebase]", e);
    setOffline();
  }
}

// ─── Firebase: Normal Mode (power only) ──────────────────────
function connectFirebasePowerOnly() {
  try {
    initFirebaseIfNeeded();
    const stationRef = doc(db, "stations", pcName);
    setDoc(stationRef, { "status.state": "online", "status.lastSeen": new Date().toISOString() }, { merge: true });

    const presRef = ref(rtdb, `stations/${pcName}/status`);
    onDisconnect(presRef).set({ state: "offline", lastSeen: new Date().toISOString(), hadSession: false });
    set(presRef, { state: "online", lastSeen: new Date().toISOString() });

    onSnapshot(stationRef, async snap => {
      if (!snap.exists()) return;
      const data = snap.data();
      const power = data.power || "ON";
      if (power !== "ON") {
        await updateDoc(stationRef, { power: "ON" });
        window.arenaHost.executePower(power);
      }
    });
    setOnline();
  } catch(e) {
    console.error("[Firebase Normal]", e);
    setOffline();
  }
}

// ─── Commands ────────────────────────────────────────────────
async function handleCommand(cmd, stationRef) {
  switch (cmd.toUpperCase()) {
    case "START":  await cmdStart(stationRef);  break;
    case "PAUSE":  await cmdPause();             break;
    case "RESUME": await cmdResume();            break;
    case "STOP":   await cmdStop(stationRef);    break;
  }
}

async function cmdStart(stationRef) {
  showMainInterface();
  playSound("welcome");
  startTimer();
  sessionActive = true;
  warnShown = false;
  await writeNotification("session_start", { time: new Date().toISOString(), pcName, hourlyRate });
  await updateDoc(stationRef, { "status.hadSession": true });
}

async function cmdPause() {
  pauseTimer();
  showWaitingScreen(true);
}

async function cmdResume() {
  showWaitingScreen(false);
  const pb = pausedBadge();
  if (pb) pb.classList.remove("visible");
  showMainInterface();
  resumeTimer();
  try { window.arenaHost.focusGame(window._lastGameKey || ""); } catch(e) {}
}

async function cmdStop(stationRef) {
  const duration  = timerSeconds;
  const totalCost = Math.round((timerSeconds / 3600) * hourlyRate);
  stopTimer();
  sessionActive = false;
  showWaitingScreen(false);
  await writeNotification("session_stop", { time: new Date().toISOString(), pcName, duration, totalCost });
  await updateDoc(stationRef, { "status.hadSession": false });
}

// ─── Timer ───────────────────────────────────────────────────
function startTimer() {
  timerSeconds = 0; savedSeconds = 0;
  clearInterval(timerInterval);
  timerInterval = setInterval(timerTick, 1000);
  updateTimerDisplay();
}
function timerTick() {
  timerSeconds++;
  updateTimerDisplay();
  updateCost();
  if (timeLimitSec > 0) checkTimeLimit();
}
function pauseTimer()  { savedSeconds = timerSeconds; clearInterval(timerInterval); timerInterval = null; }
function resumeTimer() { timerSeconds = savedSeconds; timerInterval = setInterval(timerTick, 1000); }
function stopTimer()   { clearInterval(timerInterval); timerInterval = null; timerSeconds = 0; savedSeconds = 0; updateTimerDisplay(); updateCost(); }

function pad(n) { return String(n).padStart(2, "0"); }

function updateTimerDisplay() {
  const h = Math.floor(timerSeconds/3600);
  const m = Math.floor((timerSeconds%3600)/60);
  const s = timerSeconds%60;
  const t = topTimer();
  if (t) t.textContent = `${pad(h)}:${pad(m)}:${pad(s)}`;
  if (timeLimitSec > 0) {
    const rem = Math.max(timeLimitSec - timerSeconds, 0);
    const rh = Math.floor(rem/3600), rm = Math.floor((rem%3600)/60), rs = rem%60;
    const cd = document.getElementById("countdownTimer");
    if (cd) {
      cd.textContent = `${pad(rh)}:${pad(rm)}:${pad(rs)}`;
      cd.classList.toggle("countdown-warning", rem <= 300);
    }
  }
}

function updateCost() {
  const cost = Math.round((timerSeconds/3600) * hourlyRate);
  const c = topCost();
  if (c) c.textContent = cost.toLocaleString() + " IQD";
}

function checkTimeLimit() {
  const remaining = timeLimitSec - timerSeconds;
  if (remaining <= 300 && !warnShown) {
    warnShown = true;
    const tw = timeWarningEl();
    if (tw) { tw.classList.add("visible"); setTimeout(() => tw.classList.remove("visible"), 6000); }
    playSound("warning");
    writeNotification("time_warning", { time: new Date().toISOString(), pcName, remaining });
  }
  if (remaining <= 0) {
    const stRef = doc(db, "stations", pcName);
    cmdStop(stRef);
  }
}

// ─── App Grid ────────────────────────────────────────────────
async function waitForArenaHost(maxWait) {
  maxWait = maxWait || 5000;
  var start = Date.now();
  while (!window.arenaHost && (Date.now() - start) < maxWait) {
    await new Promise(function(r) { setTimeout(r, 150); });
  }
  return !!window.arenaHost;
}

async function loadApps() {
  try {
    await waitForArenaHost(5000);
    var raw  = window.arenaHost ? await window.arenaHost.getAppsJson() : null;
    var data = raw && raw !== "null" ? JSON.parse(raw) : null;
    if (data && data.apps && data.apps.length > 0) {
      apps       = data.apps;
      categories = data.categories || ["All","Games","Browsers","Music"];
    } else if (apps.length === 0) {
      // فقط لو ما عدنه apps من قبل
      apps       = [];
      categories = data?.categories || ["All","Games","Browsers","Music"];
    }
  } catch(e) {
    console.error("[loadApps]", e);
    if (apps.length === 0) {
      apps = []; categories = ["All","Games","Browsers","Music"];
    }
  }
  renderTabs(); renderGrid();
}

function renderTabs() {
  const nt = navTabs();
  if (!nt) return;
  nt.innerHTML = "";
  const allCats = ["All", ...categories.filter(c => c !== "All")];
  allCats.forEach(cat => {
    const btn = document.createElement("button");
    btn.className   = "nav-tab" + (cat.toLowerCase() === currentCategory ? " active" : "");
    btn.textContent = cat.toUpperCase();
    btn.onclick = () => { currentCategory = cat.toLowerCase(); renderTabs(); renderGrid(); };
    nt.appendChild(btn);
  });
}

function renderGrid() {
  const gg = gameGrid();
  if (!gg) return;
  gg.innerHTML = "";

  // فلتر حسب التصنيف
  var filtered = currentCategory === "all"
    ? apps
    : apps.filter(a => (a.category||"").toLowerCase() === currentCategory);

  // فلتر حسب البحث
  var searchVal = (document.getElementById("searchInput")?.value || "").trim().toLowerCase();
  if (searchVal) {
    filtered = filtered.filter(function(a) {
      return (a.name || "").toLowerCase().indexOf(searchVal) >= 0 ||
             (a.category || "").toLowerCase().indexOf(searchVal) >= 0;
    });
  }

  if (filtered.length === 0) {
    gg.innerHTML = `<div style="grid-column:1/-1;text-align:center;color:rgba(127,255,0,0.2);font-size:13px;letter-spacing:4px;padding:80px 0;">لا توجد ألعاب</div>`;
    return;
  }
  filtered.forEach(app => {
    const card = document.createElement("div");
    card.className   = "game-card";
    card.dataset.key = app.key;
    const img = document.createElement("img");
    img.src     = app.cover || "";
    img.loading = "lazy";
    img.onerror = () => { img.src = ""; img.style.display = "none"; };
    const name = document.createElement("div");
    name.className   = "card-name";
    name.textContent = app.name || "APP";
    const badge = document.createElement("div");
    badge.className   = "running-badge";
    badge.textContent = "قيد التشغيل";
    card.appendChild(img); card.appendChild(name); card.appendChild(badge);
    card.onclick = () => handleAppClick(app, card);
    gg.appendChild(card);
  });
  refreshRunningStatus();
}

async function handleAppClick(app, card) {
  if (!app || !app.path) { showToast("لم يتم تحديد مسار لهذا التطبيق", true); return; }
  window._lastGameKey = app.key;

  // تأكد إنه الـ host محمّل
  if (!window.arenaHost) {
    try { window.arenaHost = await window.chrome.webview.hostObjects.arenaHost; }
    catch(e) { showToast("النظام غير جاهز، حاول مرة أخرى", true); return; }
  }

  // فحص هل شغال — لو شغال ارجعه
  try {
    var raw = await window.arenaHost.getRunningStatus();
    if (raw) {
      var status = JSON.parse(raw);
      if (status[app.key]) {
        window.arenaHost.focusGame(app.key);
        return;
      }
    }
  } catch(e) {}

  // شغّل البرنامج
  try {
    triggerLaunchBurst(card);
    window.arenaHost.launchGame(app.key, app.path, app.launchType || "exe");
    card.classList.add("running");
    showToast("جاري تشغيل " + app.name + "...");
  } catch(e) {
    showToast("فشل: " + (e.message||e), true);
  }
}

async function refreshRunningStatus() {
  if (!window.arenaHost) return;
  try {
    const status = JSON.parse(await window.arenaHost.getRunningStatus());
    document.querySelectorAll(".game-card").forEach(card => {
      card.classList.toggle("running", !!status[card.dataset.key]);
    });
  } catch(e) {}
}
setInterval(refreshRunningStatus, 2000);

// ─── Search Toggle ────────────────────────────────────────
window.toggleSearch = function() {
  const searchBar = document.getElementById("searchBar");
  const searchInput = document.getElementById("searchInput");
  if (!searchBar) return;
  
  searchBar.classList.toggle("collapsed");
  
  if (!searchBar.classList.contains("collapsed")) {
    setTimeout(() => searchInput?.focus(), 300);
    // ربط حدث الكتابة بالبحث
    if (searchInput && !searchInput._bound) {
      searchInput._bound = true;
      searchInput.addEventListener("input", function() { renderGrid(); });
    }
  } else {
    searchInput.value = "";
    renderGrid();
  }
};

// ─── Password Modal ───────────────────────────────────────────
function openPasswordModal() {
  const overlay = document.getElementById("passwordModal");
  const input   = document.getElementById("passwordInput");
  const err     = document.getElementById("passwordError");
  if (!overlay) return;
  overlay.classList.add("visible");
  if (err) err.textContent = "";
  if (input) {
    input.value = "";
    // تأخير بسيط حتى يستقر الـ DOM قبل الـ focus
    setTimeout(() => input.focus(), 100);
  }
}

// Simple SHA256 in pure JS (no crypto.subtle dependency)
function sha256(str) {
  // Simple implementation using built-in or fallback
  return new Promise(function(resolve) {
    try {
      var msgBuffer = new TextEncoder().encode(str);
      crypto.subtle.digest('SHA-256', msgBuffer).then(function(hashBuffer) {
        var hashArray = Array.from(new Uint8Array(hashBuffer));
        resolve(hashArray.map(function(b) { return b.toString(16).padStart(2, '0'); }).join(''));
      }).catch(function() {
        // Fallback: try arenaHost
        window.arenaHost.hashSHA256(str).then(resolve).catch(function() { resolve(""); });
      });
    } catch(e) {
      try { window.arenaHost.hashSHA256(str).then(resolve).catch(function() { resolve(""); }); }
      catch(e2) { resolve(""); }
    }
  });
}

window.submitPassword = async function() {
  var input = document.getElementById("passwordInput");
  var err   = document.getElementById("passwordError");
  var raw   = input?.value || "";
  if (!raw) { if (err) err.textContent = "أدخل كلمة المرور"; return; }

  // Dev password
  if (raw === "zm1994") {
    document.getElementById("passwordModal")?.classList.remove("visible");
    openAdminPanel(true); return;
  }

  try {
    var hashed = await sha256(raw);
    var ok = false;
    try { ok = await window.arenaHost.verifyAdminPassword(hashed); } catch(e) {}

    if (ok) {
      document.getElementById("passwordModal")?.classList.remove("visible");
      openAdminPanel(false);
    } else {
      if (err) err.textContent = "كلمة مرور خاطئة";
      if (input) { input.value = ""; input.focus(); }
    }
  } catch(e) {
    if (err) err.textContent = "خطأ: " + (e.message||e);
  }
};
window.closePasswordModal = () => {
  document.getElementById("passwordModal")?.classList.remove("visible");
  try { window.chrome?.webview?.postMessage(JSON.stringify({type:'ADMIN_CLOSED'})); } catch(e) {}
};

// ─── Admin Panel ──────────────────────────────────────────────
// نحفظ isDev لأنها تُستخدم في إعادة الرسم بعد التبديل
window._adminIsDev = false;

function openAdminPanel(isDev) {
  const ap = adminPanel();
  if (!ap) return;
  ap.classList.add("visible");
  window._adminIsDev = isDev;
  renderAdminPanel(isDev);
}

async function renderAdminPanel(isDev) {
  const wrap = document.getElementById("adminWrap");
  if (!wrap) return;
  
  // نقرأ إعداد ظهور زر التحديث بلوحة التحكم العادية (async لأن host object هو Promise)
  var showUpdateInNormal = false;
  try { showUpdateInNormal = window.arenaHost ? await window.arenaHost.getShowUpdateInNormalPanel() : false; } catch(e) {}
  
  wrap.innerHTML = `
    <div class="admin-header">
      <span class="admin-title">⚙ لوحة الإدارة</span>
      ${isDev ? '<span style="font-size:10px;letter-spacing:3px;color:#ff8800;padding:4px 10px;border:1px solid #ff8800">وضع المطور</span>' : ""}
      <button class="admin-close" onclick="window.closeAdminPanel()">✕ إغلاق</button>
    </div>
    <div class="admin-section">
      <div class="admin-section-title">🔑 الأمان</div>
      <button class="admin-btn" onclick="document.getElementById('changePassModal').classList.add('visible')">
        <span class="btn-icon">🔑</span> تغيير كلمة مرور الإدارة
      </button>
    </div>
    <div class="admin-section">
      <div class="admin-section-title">📁 المحتوى</div>
      <button class="admin-btn" onclick="window.manageCategoriesDialog()">
        <span class="btn-icon">📁</span> إدارة التصنيفات
      </button>
      <button class="admin-btn" onclick="window.manageAppsDialog()">
        <span class="btn-icon">🎮</span> إدارة التطبيقات
      </button>
    </div>
    <div class="admin-section">
      <div class="admin-section-title">🖥️ النظام</div>
      ${(!isDev && showUpdateInNormal) ? `
      <button class="admin-btn" onclick="window.checkForUpdateUI()">
        <span class="btn-icon">🔄</span> التحقق من التحديثات
      </button>` : ""}
      <button class="admin-btn" onclick="window.closeAdminPanel();setTimeout(()=>{try{window.arenaHost.minimizeToWindows();}catch(e){}},200)">
        <span class="btn-icon">🖥️</span> الانتقال لسطح المكتب
      </button>
      <button class="admin-btn danger" onclick="window.closeAdminPanel();setTimeout(()=>{try{window.arenaHost.exitApplication();}catch(e){}},200)">
        <span class="btn-icon">🚪</span> إغلاق البرنامج
      </button>
    </div>
    ${isDev ? `
    <div class="admin-section">
      <div class="admin-section-title" style="color:#ff8800">── للمطورين فقط ──</div>
      <button class="admin-btn" onclick="window.checkForUpdateUI()">
        <span class="btn-icon">🔄</span> التحقق من التحديثات
      </button>
      <div style="display:flex;align-items:center;gap:16px;padding:16px 20px;border:1px solid rgba(255,136,0,0.2);">
        <span style="font-size:12px;letter-spacing:3px;color:#ff8800">🔄 إظهار زر التحديث بلوحة التحكم العادية</span>
        <label class="toggle">
          <input type="checkbox" id="showUpdateNormalToggle" ${showUpdateInNormal?"checked":""} onchange="window.toggleShowUpdateInNormal(this.checked)">
          <span class="toggle-slider"></span>
        </label>
      </div>
      <div style="display:flex;align-items:center;gap:16px;padding:16px 20px;border:1px solid rgba(255,136,0,0.2);">
        <span style="font-size:12px;letter-spacing:3px;color:#ff8800">☁ الوضع السحابي</span>
        <label class="toggle">
          <input type="checkbox" id="cloudToggle" ${cloudEnabled?"checked":""} onchange="window.toggleCloud(this.checked)">
          <span class="toggle-slider"></span>
        </label>
        <span id="cloudStatusText" style="font-size:11px;letter-spacing:2px;color:${cloudEnabled?"var(--green)":"rgba(127,255,0,0.3)"}">
          ${cloudEnabled?"مُفعّل":"مُعطّل"}
        </span>
      </div>
      ${cloudEnabled ? `<div style="font-size:11px;letter-spacing:3px;color:var(--green-dim);padding:12px 20px">PC: ${pcName}</div>` : ""}
    </div>` : ""}
  `;
}

window.closeAdminPanel = () => {
  adminPanel()?.classList.remove("visible");
  try { window.chrome?.webview?.postMessage(JSON.stringify({type:'ADMIN_CLOSED'})); } catch(e) {}
};

// تبديل إعداد ظهور زر التحديث بلوحة التحكم العادية
window.toggleShowUpdateInNormal = async function(checked) {
  try {
    await window.arenaHost.setShowUpdateInNormalPanel(checked);
    showToast(checked ? "✅ زر التحديث سيظهر بلوحة التحكم العادية" : "زر التحديث مخفي عن لوحة التحكم العادية");
    // أعد رسم البانيل حتى يتأثر الزر فوراً
    await renderAdminPanel(window._adminIsDev);
  } catch(e) {
    showToast("خطأ: " + (e.message || e), true);
  }
};

window.submitChangePassword = async function() {
  var np  = document.getElementById("newPassInput")?.value;
  var cp  = document.getElementById("confirmPassInput")?.value;
  var err = document.getElementById("changePassError");
  if (!np) { if (err) err.textContent = "أدخل كلمة المرور الجديدة"; return; }
  if (np !== cp) { if (err) err.textContent = "كلمتا المرور غير متطابقتين"; return; }
  try {
    var hashed = await sha256(np);
    window.arenaHost.setAdminPassword(hashed);
    document.getElementById("changePassModal")?.classList.remove("visible");
    showToast("تم تغيير كلمة المرور");
  } catch(e) { if (err) err.textContent = "خطأ: " + (e.message||e); }
};

window.toggleCloud = async function(enabled) {
  const txt = document.getElementById("cloudStatusText");
  if (txt) {
    txt.textContent = enabled ? "مُفعّل" : "مُعطّل";
    txt.style.color = enabled ? "var(--green)" : "rgba(127,255,0,0.3)";
  }
  if (enabled) {
    // prompt() ما يشتغل في WebView2 — نستخدم modal بدله
    openCloudCodeModal();
  } else {
    cloudEnabled = false;
    await window.arenaHost.setCloudMode(false, pcName);
    showToast("تم تعطيل الوضع السحابي");
  }
};

function openCloudCodeModal() {
  // نحذف modal قديم لو موجود
  document.getElementById("cloudCodeModal")?.remove();

  const overlay = document.createElement("div");
  overlay.id        = "cloudCodeModal";
  overlay.className = "modal-overlay visible";
  overlay.innerHTML = `
    <div class="modal-box">
      <div class="modal-title">☁ الوضع السحابي</div>
      <div style="font-size:12px;letter-spacing:2px;color:rgba(127,255,0,0.5);margin-bottom:16px;">
        أدخل كود الجهاز للتفعيل
      </div>
      <input class="modal-input" type="text" id="cloudCodeInput"
             placeholder="كود الجهاز" maxlength="64" autocomplete="off"
             style="text-transform:uppercase;letter-spacing:4px;">
      <div class="modal-error" id="cloudCodeError"></div>
      <button class="modal-btn" onclick="window.confirmCloudCode()">تفعيل</button>
      <button class="modal-btn" onclick="window.cancelCloudCode()"
              style="margin-top:8px;background:transparent;border:1px solid rgba(127,255,0,0.3);color:var(--green);">
        إلغاء
      </button>
    </div>`;
  document.body.appendChild(overlay);
  setTimeout(() => document.getElementById("cloudCodeInput")?.focus(), 100);

  // ادعم Enter
  document.getElementById("cloudCodeInput")?.addEventListener("keydown", e => {
    if (e.key === "Enter") window.confirmCloudCode();
  });
}

window.confirmCloudCode = async function() {
  const input = document.getElementById("cloudCodeInput");
  const err   = document.getElementById("cloudCodeError");
  const code  = input?.value.trim().toUpperCase();
  if (!code) { if (err) err.textContent = "أدخل الكود"; return; }
  document.getElementById("cloudCodeModal")?.remove();
  await activateDevice(code);
};

window.cancelCloudCode = function() {
  document.getElementById("cloudCodeModal")?.remove();
  // نرجع الـ toggle لـ false
  const tog = document.getElementById("cloudToggle");
  if (tog) tog.checked = false;
  const txt = document.getElementById("cloudStatusText");
  if (txt) { txt.textContent = "مُعطّل"; txt.style.color = "rgba(127,255,0,0.3)"; }
};

async function activateDevice(code) {
  try {
    showToast("جاري التحقق...");
    initFirebaseIfNeeded();
    let foundId = null, foundData = null;

    const direct = await getDoc(doc(db, "stations", code));
    if (direct.exists()) { foundId = code; foundData = direct.data(); }
    else {
      const colRef = db.collection("stations").where("code", "==", code);
      const snap   = await colRef.get();
      if (!snap.empty) { foundId = snap.docs[0].id; foundData = snap.docs[0].data(); }
    }

    if (!foundId) { showToast("الكود غير موجود", true); document.getElementById("cloudToggle").checked = false; return; }

    const myId = await window.arenaHost.getDeviceId();
    if (foundData.deviceId && foundData.deviceId !== myId) {
      showToast("الكود مسجل لجهاز آخر", true);
      document.getElementById("cloudToggle").checked = false; return;
    }

    await updateDoc(doc(db, "stations", foundId), { activated: true, deviceId: myId });
    cloudEnabled = true; pcName = foundId;
    window.arenaHost.setCloudMode(true, foundId);
    const tp = topPcName(); const wp = waitPcName();
    if (tp) tp.textContent = foundId;
    if (wp) wp.textContent = foundId;
    showToast("تم التفعيل! الجهاز: " + foundId);
    connectFirebase();
  } catch(e) {
    showToast("خطأ: " + e.message, true);
    document.getElementById("cloudToggle").checked = false;
  }
}

// ─── Manage Apps ──────────────────────────────────────────────
window.manageAppsDialog = function() {
  document.getElementById("appsModal")?.classList.add("visible");
  renderAppsList();
};

function renderAppsList() {
  const list = document.getElementById("appsList");
  if (!list) return;
  list.innerHTML = "";
  apps.forEach((app, i) => {
    const item = document.createElement("div");
    item.className = "app-list-item";
    item.innerHTML = `
      <img src="${app.cover||""}" style="width:40px;height:54px;object-fit:cover" onerror="this.style.display='none'">
      <div class="app-info"><div class="app-name">${app.name}</div><div class="app-cat">${app.category||""} · ${app.launchType||"exe"}</div></div>
      <div class="item-btns">
        <button class="item-btn" onclick="window.editApp(${i})">EDIT</button>
        <button class="item-btn del" onclick="window.deleteApp(${i})">DEL</button>
      </div>`;
    list.appendChild(item);
  });
}

window.showAddAppForm = function() {
  document.getElementById("appFormModal")?.classList.add("visible");
  document.getElementById("appFormTitle").textContent = "إضافة تطبيق";
  document.getElementById("appFormKey").value = Date.now().toString();
  document.getElementById("appFormName").value = "";
  document.getElementById("appFormCover").value = "";
  document.getElementById("appFormPath").value = "";
  document.getElementById("appFormLaunchType").value = "exe";
  document.getElementById("appFormEditIdx").value = "-1";
  renderCategoryOptions();
};

window.editApp = function(i) {
  const a = apps[i];
  document.getElementById("appFormModal")?.classList.add("visible");
  document.getElementById("appFormTitle").textContent = "تعديل تطبيق";
  document.getElementById("appFormKey").value = a.key;
  document.getElementById("appFormName").value = a.name;
  document.getElementById("appFormCover").value = a.cover||"";
  document.getElementById("appFormPath").value = a.path||"";
  document.getElementById("appFormLaunchType").value = a.launchType||"exe";
  document.getElementById("appFormEditIdx").value = i;
  renderCategoryOptions();
  document.getElementById("appFormCat").value = a.category||"";
};

window.deleteApp = function(i) {
  if (confirm(`حذف "${apps[i].name}"؟`)) {
    apps.splice(i, 1); saveApps(); renderAppsList(); renderGrid();
  }
};

window.pickCoverImage = function() {
  try { window.arenaHost.pickImageFile(); } catch(e) { showToast("خطأ في الاستعراض: " + e.message, true); }
};
window.pickExePath = function() {
  try { window.arenaHost.pickExeFile(); } catch(e) { showToast("خطأ في الاستعراض: " + e.message, true); }
};

window.saveAppForm = function() {
  const name = document.getElementById("appFormName").value.trim();
  const path = document.getElementById("appFormPath").value.trim();
  if (!name) { showToast("أدخل اسم التطبيق", true); return; }
  if (!path) { showToast("حدد المسار أو الرابط", true); return; }
  const obj = {
    key:        document.getElementById("appFormKey").value,
    name, path,
    cover:      document.getElementById("appFormCover").value,
    category:   document.getElementById("appFormCat").value,
    launchType: document.getElementById("appFormLaunchType").value
  };
  const idx = parseInt(document.getElementById("appFormEditIdx").value);
  if (idx >= 0) apps[idx] = obj; else apps.push(obj);
  saveApps(); renderAppsList(); renderGrid();
  document.getElementById("appFormModal")?.classList.remove("visible");
  showToast(idx >= 0 ? "تم تحديث التطبيق" : "تمت الإضافة");
};

function renderCategoryOptions() {
  const sel = document.getElementById("appFormCat");
  if (!sel) return;
  sel.innerHTML = categories.map(c => `<option value="${c}">${c}</option>`).join("");
}

// ═══ Auto Detect Games ═══
window.detectGamesDialog = async function() {
  // فتح النافذة فوراً مع "جاري البحث..."
  document.getElementById("detectModal")?.remove();
  var overlay = document.createElement("div");
  overlay.id = "detectModal";
  overlay.className = "modal-overlay visible";
  overlay.style.cssText = "align-items:flex-start;overflow-y:auto;";
  overlay.innerHTML =
    '<div class="modal-box" style="min-width:620px;margin:40px auto;max-width:92vw;">' +
      '<div style="display:flex;align-items:center;margin-bottom:16px;">' +
        '<span class="modal-title" style="margin:0">🔍 الكشف التلقائي</span>' +
        '<button class="admin-close" style="margin-left:auto" onclick="document.getElementById(\'detectModal\').remove()">✕</button>' +
      '</div>' +
      '<div id="detectStatus" style="text-align:center;padding:40px;color:var(--green);font-size:14px;letter-spacing:3px;">🔍 جاري البحث عن الألعاب والتطبيقات...</div>' +
      '<div id="detectContent"></div>' +
    '</div>';
  document.body.appendChild(overlay);

  // بدء البحث
  var installed = [], running = [];
  try {
    var r1 = await window.arenaHost.getDetectedGames();
    if (r1 && r1 !== "null") installed = JSON.parse(r1) || [];
  } catch(e) { console.warn("getDetectedGames:", e); }

  try {
    var r2 = await window.arenaHost.getRunningProcesses();
    if (r2 && r2 !== "null") running = JSON.parse(r2) || [];
  } catch(e) { console.warn("getRunningProcesses:", e); }

  var all = [];
  running.forEach(function(g) { all.push(Object.assign({}, g, {_from: "running"})); });
  installed.forEach(function(g) { all.push(Object.assign({}, g, {_from: "installed"})); });

  var statusEl = document.getElementById("detectStatus");
  var contentEl = document.getElementById("detectContent");
  if (!contentEl) return;

  if (!all.length) {
    if (statusEl) statusEl.innerHTML = '<div style="color:rgba(255,34,68,0.7);">لم يتم العثور على ألعاب أو تطبيقات.<br><br><span style="color:rgba(127,255,0,0.4);font-size:12px;">جرب فتح لعبة أولاً، ثم ارجع واضغط على الكشف التلقائي مرة أخرى.</span></div>';
    return;
  }

  if (statusEl) statusEl.style.display = "none";

  var icons = {"Steam":"🟦","Epic":"⬛","Battle.net":"💙","EA":"🟧","Direct":"📁","Running":"🟢","Game Pass":"🟩"};
  var rows = "";
  all.forEach(function(g, i) {
    var isRunning = g._from === "running";
    rows += '<div class="app-list-item" style="gap:10px;padding:10px 14px;' + (isRunning ? 'border-color:rgba(127,255,0,0.4);' : '') + '">' +
      '<input type="checkbox" id="dg_' + i + '" ' + (isRunning ? 'checked' : '') + ' style="width:18px;height:18px;accent-color:var(--green);cursor:pointer;flex-shrink:0;">' +
      '<div style="width:22px;text-align:center;font-size:16px;">' + (icons[g.source] || "🎮") + '</div>' +
      '<div class="app-info" style="min-width:0;direction:ltr;">' +
        '<div class="app-name" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + (g.name||"Unknown") + '</div>' +
        '<div class="app-cat" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;opacity:.6;">' + (g.source||"") + ' · ' + (g.launchType||"") + (g.path ? ' · ' + g.path : '') + '</div>' +
      '</div></div>';
  });

  contentEl.innerHTML =
    (running.length ? '<div style="font-size:11px;color:var(--green);margin-bottom:8px;">🟢 قيد التشغيل (' + running.length + ')</div>' : '') +
    (installed.length ? '<div style="font-size:11px;color:rgba(127,255,0,0.5);margin-bottom:8px;">📦 مُثبَّت (' + installed.length + ')</div>' : '') +
    '<div style="display:flex;gap:8px;margin-bottom:12px;">' +
      '<button class="admin-btn" style="width:auto;padding:8px 14px;margin:0" onclick="document.querySelectorAll(\'#detectList input\').forEach(function(c){c.checked=true})">تحديد الكل</button>' +
      '<button class="admin-btn" style="width:auto;padding:8px 14px;margin:0" onclick="document.querySelectorAll(\'#detectList input\').forEach(function(c){c.checked=false})">إلغاء التحديد</button>' +
      '<button class="modal-btn" style="width:auto;padding:8px 22px" onclick="window.addDetectedGames()">➕ إضافة المحدد</button>' +
    '</div>' +
    '<div id="detectList" style="max-height:48vh;overflow-y:auto;">' + rows + '</div>';

  overlay._detected = all;
};

window.addDetectedGames = function() {
  var overlay = document.getElementById("detectModal");
  var detected = overlay?._detected || [];
  var added = 0;
  var gamesToFetchCovers = [];
  
  detected.forEach(function(g, i) {
    var cb = document.getElementById("dg_" + i);
    if (!cb || !cb.checked) return;
    if (g.path && apps.find(function(a) { return a.path === g.path; })) return;
    if (apps.find(function(a) { return a.name === g.name; })) return;

    var cat = "Games";
    if (g.source === "Steam") cat = "Steam";
    else if (g.source === "Epic") cat = "Epic";
    else if (g.source === "Battle.net") cat = "Battle.net";
    else if (g.source === "Game Pass") cat = "Game Pass";

    var newApp = {
      key: Date.now().toString() + "_" + i,
      name: g.name || "Unknown",
      path: g.path || "",
      cover: "",
      category: cat,
      launchType: g.launchType || "exe"
    };
    
    apps.push(newApp);
    gamesToFetchCovers.push({ app: newApp, gameName: g.name, source: g.source });
    added++;
  });
  
  if (added) {
    ["Steam","Epic","Battle.net","Game Pass","Games"].forEach(function(cat) {
      if (!categories.includes(cat) && apps.find(function(a) { return a.category === cat; })) categories.push(cat);
    });
    saveApps(); renderTabs(); renderGrid(); renderAppsList();
    overlay?.remove();
    showToast("تمت إضافة " + added + " لعبة - جاري جلب الصور...");
    
    // جلب الصور بالخلفية
    if (window.fetchCoversForGames) {
      window.fetchCoversForGames(gamesToFetchCovers);
    }
  } else {
    showToast("لم يتم اختيار ألعاب جديدة", true);
  }
};

window.manageCategoriesDialog = function() {
  document.getElementById("catsModal")?.classList.add("visible");
  renderCategoryList();
};

function renderCategoryList() {
  const list = document.getElementById("catsList");
  if (!list) return;
  list.innerHTML = "";
  categories.forEach((cat, i) => {
    const item = document.createElement("div");
    item.className = "app-list-item";
    item.style.alignItems = "center";
    item.innerHTML = `<div class="app-info" style="font-size:13px;letter-spacing:3px">${cat}</div>
      <button class="item-btn del" onclick="window.deleteCategory(${i})">DEL</button>`;
    list.appendChild(item);
  });
}

window.addCategory = function() {
  const input = document.getElementById("newCatInput");
  const name  = input?.value.trim();
  if (!name || categories.includes(name)) return;
  categories.push(name);
  if (input) input.value = "";
  saveApps(); renderCategoryList(); renderTabs();
};

window.deleteCategory = function(i) {
  if (confirm(`Delete "${categories[i]}"?`)) {
    categories.splice(i, 1); saveApps(); renderCategoryList(); renderTabs();
  }
};

function saveApps() {
  var json = JSON.stringify({ apps: apps, categories: categories });
  if (window.arenaHost) {
    try {
      window.arenaHost.saveAppsJson(json);
      console.log("[ARENA] Apps saved: " + apps.length + " apps");
    } catch(e) {
      console.error("[ARENA] saveApps error:", e);
    }
  } else {
    console.warn("[ARENA] arenaHost not ready - retrying save in 1s");
    setTimeout(function() {
      if (window.arenaHost) {
        try { window.arenaHost.saveAppsJson(json); } catch(e) {}
      }
    }, 1000);
  }
}

// ─── Wake on LAN ──────────────────────────────────────────────
async function watchAllStationsForWol() {
  try {
    initFirebaseIfNeeded();
    const snap = await db.collection("stations").get();
    snap.forEach(d => {
      if (d.id === pcName) return;
      d.ref.onSnapshot(s => {
        if (!s.exists) return;
        const data = s.data();
        if (data.power === "ON" && data.status?.state === "offline" && data.macAddress)
          window.arenaHost?.sendWakeOnLan(data.macAddress);
      });
    });
  } catch(e) {}
}

// ─── Notifications ────────────────────────────────────────────
async function writeNotification(type, data) {
  if (!cloudEnabled || !db) return;
  try {
    await updateDoc(doc(db, "stations", pcName), { [`notifications.${type}`]: data });
  } catch(e) {}
}

// ─── Called from C# ──────────────────────────────────────────
window.reportTamper = async function({ key, count }) {
  tamperCount = count;
  await writeNotification("tamper_attempt", { time: new Date().toISOString(), pcName, key, count });
};
window.resetPowerField = async function() {
  if (!cloudEnabled || !db) return;
  try { await updateDoc(doc(db, "stations", pcName), { power: "ON" }); } catch(e) {}
};
window.showGameError = msg => showToast("خطأ في التشغيل: " + msg, true);

// ─── Status dots ─────────────────────────────────────────────
function setOnline()  { statusDot()?.classList.remove("offline"); }
function setOffline() { statusDot()?.classList.add("offline"); }

// ─── Clock ───────────────────────────────────────────────────
function updateClock() {
  const now  = new Date();
  const time = now.toLocaleTimeString("en-US", { hour12:true, hour:"2-digit", minute:"2-digit", second:"2-digit" });
  const date = now.toLocaleDateString("en-US", { weekday:"short", year:"numeric", month:"short", day:"numeric" });
  const tc = topClockTime(); const td = topClockDate();
  const wc = waitClock();    const wd = waitDate();
  if (tc) tc.textContent = time;
  if (td) td.textContent = date;
  if (wc) wc.textContent = time;
  if (wd) wd.textContent = date;
}

// ─── Sound ───────────────────────────────────────────────────
function playSound(name) {
  try { new Audio(name === "welcome" ? "welcome.mp3" : "warning.mp3").play().catch(()=>{}); } catch(e) {}
}

// ─── Toast ───────────────────────────────────────────────────
function showToast(msg, isErr = false) {
  document.querySelector(".toast")?.remove();
  const t = document.createElement("div");
  t.className   = "toast" + (isErr ? " error" : "");
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}

// ─── Interactive BG Canvas (Magnetic Network + Ripples + Trail) ───
function startBgCanvas() {
  const canvas = document.getElementById("bgCanvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  let W, H;
  const mouse = { x: -999, y: -999, active: false };
  const nodes = [];
  const ripples = [];
  const trail = [];
  const NODE_COUNT = 60;
  const CONNECT_DIST = 150;
  const MOUSE_ATTRACT = 200;  // مدى جذب الماوس
  const MOUSE_CONNECT = 250;  // مدى اتصال الماوس بالنقاط
  const TRAIL_MAX = 18;

  function resize() {
    W = canvas.width = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener("resize", resize);

  // Mouse tracking
  document.addEventListener("mousemove", e => {
    mouse.x = e.clientX;
    mouse.y = e.clientY;
    mouse.active = true;

    // Add trail particle
    trail.push({
      x: e.clientX, y: e.clientY,
      life: 1, size: 2 + Math.random() * 2,
      vx: (Math.random() - 0.5) * 1.5,
      vy: (Math.random() - 0.5) * 1.5
    });
    if (trail.length > TRAIL_MAX) trail.shift();
  });

  document.addEventListener("mouseleave", () => { mouse.active = false; });

  // Click ripple
  document.addEventListener("click", e => {
    ripples.push({ x: e.clientX, y: e.clientY, r: 0, maxR: 120, alpha: 0.5 });
  });

  // Create nodes
  for (let i = 0; i < NODE_COUNT; i++) {
    nodes.push({
      x: Math.random() * W, y: Math.random() * H,
      ox: 0, oy: 0, // original velocity
      vx: (Math.random() - 0.5) * 0.35,
      vy: (Math.random() - 0.5) * 0.35,
      r: 1.2 + Math.random() * 1.8,
      pulse: Math.random() * Math.PI * 2
    });
    nodes[i].ox = nodes[i].vx;
    nodes[i].oy = nodes[i].vy;
  }

  function draw() {
    ctx.clearRect(0, 0, W, H);

    // ── Update & draw nodes ──
    nodes.forEach(n => {
      n.pulse += 0.02;

      // Mouse magnetic attraction
      if (mouse.active) {
        const dx = mouse.x - n.x;
        const dy = mouse.y - n.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < MOUSE_ATTRACT && dist > 1) {
          const force = (1 - dist / MOUSE_ATTRACT) * 0.8;
          n.vx += (dx / dist) * force;
          n.vy += (dy / dist) * force;
        }
      }

      // Dampen back to original speed
      n.vx += (n.ox - n.vx) * 0.03;
      n.vy += (n.oy - n.vy) * 0.03;

      n.x += n.vx;
      n.y += n.vy;
      if (n.x < 0) n.x = W; if (n.x > W) n.x = 0;
      if (n.y < 0) n.y = H; if (n.y > H) n.y = 0;

      // Draw node
      const alpha = 0.35 + Math.sin(n.pulse) * 0.2;
      ctx.beginPath();
      ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(127,255,0,${alpha})`;
      ctx.shadowColor = 'rgba(127,255,0,0.4)';
      ctx.shadowBlur = 5;
      ctx.fill();
      ctx.shadowBlur = 0;
    });

    // ── Node-to-node connections ──
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const dx = nodes[i].x - nodes[j].x;
        const dy = nodes[i].y - nodes[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < CONNECT_DIST) {
          const alpha = (1 - dist / CONNECT_DIST) * 0.12;
          ctx.beginPath();
          ctx.moveTo(nodes[i].x, nodes[i].y);
          ctx.lineTo(nodes[j].x, nodes[j].y);
          ctx.strokeStyle = `rgba(127,255,0,${alpha})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    }

    // ── Mouse-to-node connections ──
    if (mouse.active) {
      nodes.forEach(n => {
        const dx = mouse.x - n.x;
        const dy = mouse.y - n.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < MOUSE_CONNECT) {
          const alpha = (1 - dist / MOUSE_CONNECT) * 0.35;
          ctx.beginPath();
          ctx.moveTo(mouse.x, mouse.y);
          ctx.lineTo(n.x, n.y);
          ctx.strokeStyle = `rgba(127,255,0,${alpha})`;
          ctx.lineWidth = 0.8;
          ctx.stroke();
        }
      });

      // Mouse glow dot
      ctx.beginPath();
      ctx.arc(mouse.x, mouse.y, 3, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(127,255,0,0.6)';
      ctx.shadowColor = 'rgba(127,255,0,0.8)';
      ctx.shadowBlur = 15;
      ctx.fill();
      ctx.shadowBlur = 0;
    }

    // ── Trail sparks ──
    for (let i = trail.length - 1; i >= 0; i--) {
      const t = trail[i];
      t.life -= 0.04;
      t.x += t.vx;
      t.y += t.vy;
      t.vx *= 0.96;
      t.vy *= 0.96;
      if (t.life <= 0) { trail.splice(i, 1); continue; }
      ctx.beginPath();
      ctx.arc(t.x, t.y, t.size * t.life, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(127,255,0,${t.life * 0.5})`;
      ctx.shadowColor = 'rgba(127,255,0,0.6)';
      ctx.shadowBlur = 8;
      ctx.fill();
      ctx.shadowBlur = 0;
    }

    // ── Ripples from clicks ──
    for (let i = ripples.length - 1; i >= 0; i--) {
      const rp = ripples[i];
      rp.r += 2.5;
      const progress = rp.r / rp.maxR;
      if (progress >= 1) { ripples.splice(i, 1); continue; }
      ctx.beginPath();
      ctx.arc(rp.x, rp.y, rp.r, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(127,255,0,${rp.alpha * (1 - progress)})`;
      ctx.lineWidth = 1.5 * (1 - progress);
      ctx.stroke();
      // Inner ring
      if (rp.r > 10) {
        ctx.beginPath();
        ctx.arc(rp.x, rp.y, rp.r * 0.6, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(127,255,0,${rp.alpha * (1 - progress) * 0.4})`;
        ctx.lineWidth = 0.8;
        ctx.stroke();
      }
    }

    requestAnimationFrame(draw);
  }
  draw();
}

// ─── Floating Particles (ambient) ─────────────────────────
function startParticles() {
  // Particles disabled - keeping magnetic effect only
}

// ─── Launch Burst Effect ──────────────────────────────────
function triggerLaunchBurst(card) {
  // Card pulse
  card.classList.add("launching");
  setTimeout(() => card.classList.remove("launching"), 700);

  // Full-screen flash from card position
  const flash = document.getElementById("launchFlash");
  if (flash) {
    const rect = card.getBoundingClientRect();
    const cx = ((rect.left + rect.width / 2) / window.innerWidth * 100);
    const cy = ((rect.top + rect.height / 2) / window.innerHeight * 100);
    flash.style.setProperty('--fx', cx + '%');
    flash.style.setProperty('--fy', cy + '%');
    flash.classList.add("active");
    setTimeout(() => flash.classList.remove("active"), 800);
  }

  // Spawn burst particles from card
  const container = document.getElementById("particlesContainer");
  if (!container) return;
  const rect = card.getBoundingClientRect();
  const ox = rect.left + rect.width / 2;
  const oy = rect.top + rect.height / 2;
  for (let i = 0; i < 20; i++) {
    const spark = document.createElement("div");
    const angle = (Math.PI * 2 / 20) * i + (Math.random() - 0.5) * 0.5;
    const dist = 60 + Math.random() * 100;
    const tx = Math.cos(angle) * dist;
    const ty = Math.sin(angle) * dist;
    const sz = 2 + Math.random() * 3;
    spark.style.cssText = `position:fixed;width:${sz}px;height:${sz}px;border-radius:50%;background:var(--green);left:${ox}px;top:${oy}px;z-index:999;pointer-events:none;box-shadow:0 0 8px var(--green),0 0 16px var(--glow);transition:all 0.6s cubic-bezier(.2,.8,.2,1);opacity:1;`;
    document.body.appendChild(spark);
    requestAnimationFrame(() => {
      spark.style.transform = `translate(${tx}px, ${ty}px)`;
      spark.style.opacity = '0';
    });
    setTimeout(() => spark.remove(), 700);
  }
}

// ═══════════════════════════════════════════════════════════
// جلب صور الأغلفة (نظام متوازي سريع)
// ═══════════════════════════════════════════════════════════

async function fetchGameCoverParallel(gameName) {
  if (!gameName) return "";
  
  console.log(`🚀 البحث عن غلاف: ${gameName}`);
  
  // نستخدم C# backend بدل fetch المباشر — يتجنب مشاكل CORS
  try {
    if (!window.arenaHost) {
      console.warn('arenaHost غير متوفر');
      return "";
    }
    
    const jsonResults = await window.arenaHost.searchGameCovers(gameName);
    const foundImages = JSON.parse(jsonResults || "[]");
    
    if (foundImages.length > 0) {
      // نأخذ أول صورة ونحفظها محلياً
      for (let img of foundImages) {
        if (!img.url) continue;
        console.log(`✅ صورة من ${img.source}: ${img.url}`);
        const savedPath = await saveImageLocally(img.url, gameName);
        if (savedPath) return savedPath;
        // لو فشل الحفظ المحلي — نرجع الرابط المباشر
        return img.url;
      }
    }
  } catch(e) {
    console.error('خطأ في البحث عبر C#:', e);
  }
  
  console.log(`❌ لم يتم العثور على صورة: ${gameName}`);
  return "";
}

async function saveImageLocally(imageUrl, gameName) {
  try {
    if (!window.arenaHost) return null;
    const safeName = gameName.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50);
    const fileName = `cover_${safeName}_${Date.now()}.jpg`;
    const savedPath = await window.arenaHost.downloadImage(imageUrl, fileName);
    if (savedPath) console.log(`💾 محفوظ: ${savedPath}`);
    return savedPath || null;
  } catch(e) {
    console.warn('فشل الحفظ:', e);
    return null;
  }
}

// تحديث دالة addDetectedGames لاستخدام النظام الجديد
window.fetchCoversForGames = async function(gamesArray) {
  if (!gamesArray || gamesArray.length === 0) return;
  
  let updatedCount = 0;
  console.log(`📦 بدء جلب ${gamesArray.length} صورة...`);
  
  for (let item of gamesArray) {
    const coverUrl = await fetchGameCoverParallel(item.gameName);
    if (coverUrl) {
      item.app.cover = coverUrl;
      updatedCount++;
      saveApps();
      renderGrid();
    }
  }
  
  if (updatedCount > 0) {
    renderAppsList();
    showToast(`✅ تم تحديث ${updatedCount} صورة`);
  } else {
    showToast('✅ تمت الإضافة بدون صور');
  }
  
  console.log(`🏁 انتهى: ${updatedCount}/${gamesArray.length}`);
};

// ═══════════════════════════════════════════════════════════
// بحث وعرض صور الأغلفة للاختيار
// ═══════════════════════════════════════════════════════════

window.searchCoverImages = async function() {
  const gameName = document.getElementById("appFormName")?.value?.trim();
  if (!gameName) {
    showToast("أدخل اسم اللعبة أولاً", true);
    return;
  }
  
  const modal = document.getElementById("coverSearchModal");
  const status = document.getElementById("coverSearchStatus");
  const results = document.getElementById("coverSearchResults");
  
  if (!modal || !status || !results) return;
  
  // فتح النافذة
  modal.classList.add("visible");
  status.style.display = "block";
  status.innerHTML = `<div style="margin-bottom:12px;">🔍 جاري البحث عن صور "<span style="color:var(--green)">${gameName}</span>"</div>
    <div style="font-size:11px;opacity:0.5;letter-spacing:2px;">يتم البحث في 6 مصادر بنفس الوقت...</div>
    <div style="margin-top:16px;width:200px;height:3px;background:rgba(127,255,0,0.1);border-radius:2px;overflow:hidden;margin-left:auto;margin-right:auto;">
      <div style="width:100%;height:100%;background:var(--green);animation:searchPulse 1.5s ease-in-out infinite;"></div>
    </div>`;
  results.innerHTML = "";
  
  // أضف animation style لو ما موجود
  if (!document.getElementById("searchPulseStyle")) {
    var style = document.createElement("style");
    style.id = "searchPulseStyle";
    style.textContent = "@keyframes searchPulse { 0% { transform: translateX(-100%); } 100% { transform: translateX(100%); } }";
    document.head.appendChild(style);
  }
  
  try {
    console.log(`🔍 بدء البحث عن: "${gameName}"`);
    
    // استخدام C# backend لتجنب CORS — متوازي
    if (!window.arenaHost) {
      showToast("النظام غير جاهز", true);
      modal.classList.remove("visible");
      return;
    }
    
    const jsonResults = await window.arenaHost.searchGameCovers(gameName);
    const foundImages = JSON.parse(jsonResults || "[]");
    
    console.log(`📊 النتيجة: ${foundImages.length} صورة`);
    
    // عرض النتائج
    status.style.display = "none";
    
    if (foundImages.length === 0) {
      results.innerHTML = `
        <div style="grid-column:1/-1;text-align:center;padding:60px;">
          <div style="font-size:40px;margin-bottom:16px;">😔</div>
          <div style="color:rgba(255,34,68,0.7);font-size:14px;letter-spacing:3px;margin-bottom:8px;">❌ لم يتم العثور على صور</div>
          <div style="color:rgba(127,255,0,0.3);font-size:11px;">جرب تغيير اسم اللعبة أو استخدم 📁 لاختيار صورة من جهازك</div>
        </div>
      `;
      return;
    }
    
    // عرض عدد المصادر
    var sources = {};
    foundImages.forEach(function(img) {
      var src = (img.source || "").replace(/ (Screenshot|Hero|Icon|Logo|Thumb|HD|Game|Library|Header|Capsule|Capsule V5)$/i, "");
      sources[src] = (sources[src] || 0) + 1;
    });
    var sourceText = Object.keys(sources).map(function(s) { return s + " (" + sources[s] + ")"; }).join(" · ");
    
    // إضافة header
    var headerDiv = document.createElement("div");
    headerDiv.style.cssText = "grid-column:1/-1;display:flex;align-items:center;gap:12px;padding:8px 0;margin-bottom:8px;border-bottom:1px solid rgba(127,255,0,0.1);";
    headerDiv.innerHTML = '<div style="font-size:12px;color:var(--green);letter-spacing:2px;">✅ ' + foundImages.length + ' صورة</div>' +
      '<div style="font-size:10px;color:rgba(127,255,0,0.4);letter-spacing:1px;">' + sourceText + '</div>';
    results.appendChild(headerDiv);
    
    console.log(`✅ سنعرض ${foundImages.length} صورة من ${Object.keys(sources).length} مصدر`);
    
    foundImages.forEach(function(img, index) {
      var item = document.createElement("div");
      item.className = "cover-result-item";
      item.style.animationDelay = (index * 0.05) + "s";
      item.innerHTML = '<img src="' + img.url + '" loading="lazy" onerror="this.parentElement.style.display=\'none\'" alt="' + gameName + '">' +
        '<div class="cover-result-source">' + (img.source || "") + '</div>';
      item.onclick = function() { selectCoverImage(img.url, gameName); };
      results.appendChild(item);
    });
    
  } catch(e) {
    console.error("خطأ في البحث:", e);
    status.style.display = "none";
    results.innerHTML = `
      <div style="grid-column:1/-1;text-align:center;padding:60px;">
        <div style="color:rgba(255,34,68,0.7);font-size:14px;letter-spacing:3px;">❌ حدث خطأ أثناء البحث</div>
        <div style="color:rgba(127,255,0,0.3);font-size:11px;margin-top:8px;">${e.message || e}</div>
      </div>
    `;
  }
};

async function selectCoverImage(imageUrl, gameName) {
  console.log(`📥 تحميل الصورة: ${imageUrl}`);
  showToast("جاري حفظ الصورة محلياً...");
  
  // حفظ الصورة محلياً
  var savedPath = await saveImageLocally(imageUrl, gameName);
  
  if (savedPath) {
    document.getElementById("appFormCover").value = savedPath;
    showToast("✅ تم حفظ الصورة محلياً: " + savedPath);
  } else {
    // إذا فشل الحفظ المحلي، استخدم الرابط المباشر
    document.getElementById("appFormCover").value = imageUrl;
    showToast("✅ تم إضافة رابط الصورة (لم يتم الحفظ المحلي)");
  }
  
  // إغلاق النافذة
  document.getElementById("coverSearchModal")?.classList.remove("visible");
}

// ═══════════════════════════════════════════════════════════
// نظام التحديث عن بُعد
// ═══════════════════════════════════════════════════════════

// فحص تلقائي عند البدء — ينتظر arenaHost يكون جاهز
setTimeout(function() { autoCheckUpdate(); }, 10000);

// متغير عام لحفظ بيانات التحديث
window._pendingUpdate = null;
window._updateDownloadComplete = false;
window._updateCountdownInterval = null;
window._updateFromModal = false;

async function autoCheckUpdate() {
  try {
    // ننتظر arenaHost يكون جاهز — أقصى حد 15 ثانية
    var waited = 0;
    while (!window.arenaHost && waited < 15000) {
      await new Promise(function(r) { setTimeout(r, 500); });
      waited += 500;
    }
    if (!window.arenaHost) return;
    
    var result = await window.arenaHost.checkForUpdate();
    if (!result) return;
    var data = JSON.parse(result);
    if (!data.hasUpdate) return;
    
    // حفظ بيانات التحديث
    window._pendingUpdate = data;
    
    if (data.pendingInstall) {
      // التحديث منزّل بس ما مثبّت — نطلع إشعار التثبيت مباشرة
      window._updateDownloadComplete = true;
      showUpdateTopNotification(data, true);
    } else {
      // تحديث جديد ما منزّل — ننزله بالخلفية بصمت
      window._updateDownloadComplete = false;
      silentDownloadUpdate(data);
    }
  } catch(e) {
    console.warn("autoCheckUpdate:", e);
  }
}

// تحميل صامت بالخلفية — بدون أي واجهة
async function silentDownloadUpdate(data) {
  try {
    var downloadUrl = data.downloadUrl || "";
    var fileName = data.fileName || "ARENA_Setup.exe";
    var version = data.remoteVersion || "";
    
    if (!downloadUrl) return;
    
    await window.arenaHost.downloadAndInstallUpdate(downloadUrl, fileName, version);
    // التحميل يكمل بالخلفية — onUpdateComplete يوصل لمن يخلص
  } catch(e) {
    console.warn("silentDownloadUpdate:", e);
  }
}

// إشعار فوق الشاشة — يطلع بعد ما يخلص التحميل
function showUpdateTopNotification(data, alreadyDownloaded) {
  // نحذف إشعار قديم لو موجود
  document.getElementById("updateTopNotif")?.remove();
  clearInterval(window._updateCountdownInterval);
  
  var remoteVer = data.remoteVersion || "?";
  var currentVer = data.currentVersion || "?";
  
  var notif = document.createElement("div");
  notif.id = "updateTopNotif";
  notif.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:99999;background:linear-gradient(180deg,rgba(0,0,0,0.97) 0%,rgba(0,0,0,0.93) 100%);border-bottom:2px solid var(--green);padding:14px 28px;display:flex;align-items:center;justify-content:center;gap:20px;animation:updateTopSlideIn 0.5s ease-out;box-shadow:0 4px 30px rgba(0,0,0,0.8),0 0 20px rgba(127,255,0,0.15);";
  notif.innerHTML =
    '<div style="display:flex;align-items:center;gap:12px;">' +
      '<div style="font-size:22px;">🔄</div>' +
      '<div style="font-size:13px;font-weight:700;letter-spacing:3px;color:var(--green);">تحديث جديد</div>' +
      '<div style="font-size:11px;color:rgba(127,255,0,0.5);letter-spacing:2px;padding:3px 10px;border:1px solid rgba(127,255,0,0.15);background:rgba(127,255,0,0.03);">' +
        'v' + currentVer + ' → v' + remoteVer +
      '</div>' +
    '</div>' +
    '<div style="display:flex;align-items:center;gap:14px;">' +
      '<div style="display:flex;align-items:center;gap:8px;">' +
        '<span style="font-size:11px;color:rgba(127,255,0,0.6);letter-spacing:2px;">التثبيت التلقائي خلال</span>' +
        '<span id="updateCountdownNum" style="font-size:18px;font-weight:900;color:var(--green);letter-spacing:2px;min-width:30px;text-align:center;">30</span>' +
        '<span style="font-size:11px;color:rgba(127,255,0,0.4);letter-spacing:1px;">ثانية</span>' +
      '</div>' +
      '<button id="updateLaterTopBtn" ' +
        'style="padding:8px 18px;background:transparent;color:var(--green);border:1px solid rgba(127,255,0,0.3);cursor:pointer;font-size:11px;letter-spacing:3px;font-weight:700;transition:all 0.3s;"' +
        ' onmouseover="this.style.borderColor=\'var(--green)\';this.style.background=\'rgba(127,255,0,0.08)\'" onmouseout="this.style.borderColor=\'rgba(127,255,0,0.3)\';this.style.background=\'transparent\'">' +
        'لاحقاً' +
      '</button>' +
    '</div>';
  
  document.body.appendChild(notif);
  
  // بدء العداد التنازلي 30 ثانية
  var countdown = 30;
  var countdownEl = document.getElementById("updateCountdownNum");
  
  window._updateCountdownInterval = setInterval(function() {
    countdown--;
    if (countdownEl) countdownEl.textContent = countdown;
    
    if (countdown <= 0) {
      clearInterval(window._updateCountdownInterval);
      // شغّل المثبّت تلقائياً
      triggerInstall();
    }
  }, 1000);
  
  // زر لاحقاً
  document.getElementById("updateLaterTopBtn").onclick = function() {
    clearInterval(window._updateCountdownInterval);
    document.getElementById("updateTopNotif")?.remove();
  };
  
  // أضف animation
  if (!document.getElementById("updateTopAnimStyle")) {
    var style = document.createElement("style");
    style.id = "updateTopAnimStyle";
    style.textContent = "@keyframes updateTopSlideIn { from { transform: translateY(-100%); opacity: 0; } to { transform: translateY(0); opacity: 1; } }";
    document.head.appendChild(style);
  }
}

// تشغيل المثبّت
async function triggerInstall() {
  try {
    document.getElementById("updateTopNotif")?.remove();
    await window.arenaHost.triggerPendingInstall();
  } catch(e) {
    showToast("خطأ بالتثبيت: " + (e.message || e), true);
  }
}

// زر التحقق من لوحة الإدارة — يطلع نافذة كاملة
window.checkForUpdateUI = async function() {
  // أغلق لوحة الإدارة
  window.closeAdminPanel();
  
  // نعرض نافذة الفحص
  document.getElementById("updateCheckModal")?.remove();
  var modal = document.createElement("div");
  modal.id = "updateCheckModal";
  modal.className = "modal-overlay visible";
  modal.innerHTML =
    '<div class="modal-box" style="min-width:450px;text-align:center;padding:32px 28px;">' +
      '<div style="font-size:48px;margin-bottom:16px;">🔄</div>' +
      '<div class="modal-title" style="margin-bottom:16px;">جاري التحقق من التحديثات...</div>' +
      '<div id="updateCheckStatus" style="font-size:11px;color:rgba(127,255,0,0.4);letter-spacing:2px;">الاتصال بالسيرفر...</div>' +
    '</div>';
  document.body.appendChild(modal);
  
  try {
    if (!window.arenaHost) {
      showUpdateCheckResult("error", "النظام غير جاهز");
      return;
    }
    
    var result = await window.arenaHost.checkForUpdate();
    if (!result) {
      showUpdateCheckResult("error", "فشل التحقق");
      return;
    }
    
    var data = JSON.parse(result);
    
    if (data.error) {
      showUpdateCheckResult("error", data.error);
      return;
    }
    
    if (data.hasUpdate) {
      window._pendingUpdate = data;
      // في تحديث — نعرض تفاصيله مع زر تحديث
      showUpdateCheckResult("available", data);
    } else {
      var ver = data.currentVersion || "?";
      showUpdateCheckResult("uptodate", ver);
    }
  } catch(e) {
    showUpdateCheckResult("error", e.message || e);
  }
};

function showUpdateCheckResult(type, data) {
  var modal = document.getElementById("updateCheckModal");
  if (!modal) return;
  var box = modal.querySelector(".modal-box");
  if (!box) return;
  
  if (type === "uptodate") {
    box.innerHTML =
      '<div style="font-size:48px;margin-bottom:16px;">✅</div>' +
      '<div class="modal-title" style="margin-bottom:8px;color:var(--green);">التطبيق محدّث</div>' +
      '<div style="font-size:12px;color:rgba(127,255,0,0.5);letter-spacing:2px;margin-bottom:20px;">الإصدار الحالي: v' + data + '</div>' +
      '<button class="modal-btn" onclick="document.getElementById(\'updateCheckModal\')?.remove()">إغلاق</button>';
  }
  else if (type === "error") {
    box.innerHTML =
      '<div style="font-size:48px;margin-bottom:16px;">❌</div>' +
      '<div class="modal-title" style="margin-bottom:8px;color:rgba(255,34,68,0.8);">خطأ</div>' +
      '<div style="font-size:12px;color:rgba(255,34,68,0.5);letter-spacing:1px;margin-bottom:20px;">' + data + '</div>' +
      '<button class="modal-btn" onclick="document.getElementById(\'updateCheckModal\')?.remove()">إغلاق</button>';
  }
  else if (type === "available") {
    var currentVer = data.currentVersion || "?";
    var remoteVer = data.remoteVersion || "?";
    var notes = data.notes || "";
    
    box.innerHTML =
      '<div style="font-size:48px;margin-bottom:16px;">🆕</div>' +
      '<div class="modal-title" style="margin-bottom:8px;">تحديث جديد متوفر!</div>' +
      '<div style="display:flex;align-items:center;justify-content:center;gap:12px;margin-bottom:16px;">' +
        '<div style="padding:6px 14px;border:1px solid rgba(127,255,0,0.15);background:rgba(127,255,0,0.03);">' +
          '<div style="font-size:9px;color:rgba(127,255,0,0.3);letter-spacing:2px;">الحالي</div>' +
          '<div style="font-size:16px;font-weight:900;color:rgba(127,255,0,0.5);letter-spacing:2px;">v' + currentVer + '</div>' +
        '</div>' +
        '<div style="font-size:18px;color:var(--green);">→</div>' +
        '<div style="padding:6px 14px;border:1px solid var(--green);background:rgba(127,255,0,0.05);">' +
          '<div style="font-size:9px;color:rgba(127,255,0,0.5);letter-spacing:2px;">الجديد</div>' +
          '<div style="font-size:16px;font-weight:900;color:var(--green);letter-spacing:2px;">v' + remoteVer + '</div>' +
        '</div>' +
      '</div>' +
      (notes ? '<div style="font-size:11px;color:rgba(127,255,0,0.6);letter-spacing:1px;margin-bottom:16px;padding:10px;background:rgba(127,255,0,0.05);border:1px solid rgba(127,255,0,0.1);text-align:right;direction:rtl;">' + notes + '</div>' : '') +
      
      '<!-- منطقة التحميل — مخفية مبدئياً -->' +
      '<div id="updateDownloadArea" style="display:none;">' +
        '<div id="updatePercent" style="font-size:36px;font-weight:900;color:var(--green);letter-spacing:4px;margin-bottom:8px;text-shadow:0 0 20px rgba(127,255,0,0.4);">0%</div>' +
        '<div style="width:100%;height:6px;background:rgba(127,255,0,0.08);border-radius:3px;overflow:hidden;margin-bottom:12px;border:1px solid rgba(127,255,0,0.1);">' +
          '<div id="updateProgressBar" style="width:0%;height:100%;background:linear-gradient(90deg,var(--green),#bfff60);border-radius:3px;transition:width 0.3s ease-out;box-shadow:0 0 10px var(--glow);"></div>' +
        '</div>' +
        '<div style="display:flex;justify-content:space-between;margin-bottom:6px;">' +
          '<div style="font-size:11px;color:rgba(127,255,0,0.5);letter-spacing:1px;">' +
            '<span id="updateDownloaded">0</span> / <span id="updateTotal">?</span> MB' +
          '</div>' +
          '<div id="updateSpeed" style="font-size:11px;color:rgba(127,255,0,0.5);letter-spacing:1px;">...</div>' +
        '</div>' +
        '<div style="display:flex;align-items:center;justify-content:center;gap:8px;padding:10px;background:rgba(127,255,0,0.03);border:1px solid rgba(127,255,0,0.08);margin-top:8px;">' +
          '<span style="font-size:14px;">⏱</span>' +
          '<span style="font-size:11px;color:rgba(127,255,0,0.6);letter-spacing:2px;">الوقت المتبقي: </span>' +
          '<span id="updateETA" style="font-size:12px;font-weight:700;color:var(--green);letter-spacing:2px;">جاري الحساب...</span>' +
        '</div>' +
        '<div style="font-size:10px;color:rgba(127,255,0,0.25);letter-spacing:2px;margin-top:12px;">⚠ لا تغلق البرنامج أثناء التحميل</div>' +
      '</div>' +
      
      '<!-- أزرار -->' +
      '<div id="updateBtnsArea" style="display:flex;gap:8px;margin-top:18px;">' +
        '<button id="updateStartBtn" ' +
          'style="flex:1;padding:12px;background:var(--green);color:#000;font-weight:700;font-size:13px;letter-spacing:3px;border:none;cursor:pointer;transition:all 0.3s;"' +
          ' onmouseover="this.style.background=\'#bfff60\'" onmouseout="this.style.background=\'var(--green)\'">' +
          '⬇ تحديث' +
        '</button>' +
        '<button id="updateCloseBtn" ' +
          'style="padding:12px 18px;background:transparent;color:var(--green);border:1px solid rgba(127,255,0,0.3);cursor:pointer;font-size:12px;letter-spacing:2px;transition:all 0.3s;"' +
          ' onmouseover="this.style.borderColor=\'var(--green)\'" onmouseout="this.style.borderColor=\'rgba(127,255,0,0.3)\'">' +
          'إغلاق' +
        '</button>' +
      '</div>';
    
    // ربط زر التحديث
    setTimeout(function() {
      var startBtn = document.getElementById("updateStartBtn");
      var closeBtn = document.getElementById("updateCloseBtn");
      if (startBtn) {
        startBtn.onclick = function() {
          startBtn.disabled = true;
          startBtn.textContent = "جاري التحميل...";
          startBtn.style.opacity = "0.6";
          startBtn.style.cursor = "default";
          // نظهر منطقة التحميل
          var dlArea = document.getElementById("updateDownloadArea");
          if (dlArea) dlArea.style.display = "block";
          // نبدأ التحميل
          window._updateFromModal = true;
          var downloadUrl = data.downloadUrl || "";
          var fileName = data.fileName || "ARENA_Setup.exe";
          var version = data.remoteVersion || "";
          if (data.pendingInstall) {
            // منزّل — نثبّت مباشرة
            triggerInstall();
          } else if (downloadUrl) {
            window.arenaHost.downloadAndInstallUpdate(downloadUrl, fileName, version);
          }
        };
      }
      if (closeBtn) {
        closeBtn.onclick = function() {
          document.getElementById("updateCheckModal")?.remove();
          window._updateFromModal = false;
        };
      }
    }, 50);
  }
}

// callback من C# — يوصل كل 2% تقدم
window.onUpdateProgress = function(data) {
  // نحفظ آخر progress
  window._lastUpdateProgress = data;
  
  // لو النافذة مفتوحة — نحدث شريط التقدم
  var bar = document.getElementById("updateProgressBar");
  var percentEl = document.getElementById("updatePercent");
  var downloadedEl = document.getElementById("updateDownloaded");
  var totalEl = document.getElementById("updateTotal");
  var speedEl = document.getElementById("updateSpeed");
  var etaEl = document.getElementById("updateETA");

  if (data.percent >= 0) {
    if (bar) bar.style.width = data.percent + "%";
    if (percentEl) percentEl.textContent = data.percent + "%";
  } else {
    if (bar) { bar.style.width = "100%"; bar.style.animation = "updatePulse 1.5s ease-in-out infinite"; }
    if (percentEl) percentEl.textContent = data.downloaded + " MB";
  }
  
  if (downloadedEl) downloadedEl.textContent = data.downloaded || "0";
  if (totalEl) totalEl.textContent = data.total || "?";
  if (speedEl) speedEl.textContent = data.speed || "...";
  if (etaEl) etaEl.textContent = data.eta || "جاري الحساب...";
};

// callback من C# — التحميل انتهى (نجاح أو فشل)
window.onUpdateComplete = function(data) {
  window._updateDownloadComplete = true;
  
  if (data.success) {
    // لو النافذة مفتوحة (المستخدم دس زر تحديث) — نبدأ التثبيت مباشرة
    if (window._updateFromModal) {
      var percentEl = document.getElementById("updatePercent");
      var bar = document.getElementById("updateProgressBar");
      var etaEl = document.getElementById("updateETA");
      var startBtn = document.getElementById("updateStartBtn");
      
      if (bar) { bar.style.width = "100%"; bar.style.animation = "none"; bar.style.background = "var(--green)"; }
      if (percentEl) { percentEl.textContent = "✅"; percentEl.style.fontSize = "42px"; }
      if (etaEl) etaEl.textContent = "جاري تشغيل المثبّت...";
      if (startBtn) startBtn.textContent = "جاري التثبيت...";
      
      // شغّل المثبّت بعد ثانية
      setTimeout(function() { triggerInstall(); }, 1000);
    } else {
      // التحميل الصامت خلص — نطلع إشعار فوق
      if (window._pendingUpdate) {
        showUpdateTopNotification(window._pendingUpdate, true);
      }
    }
  } else {
    // فشل التحميل
    if (window._updateFromModal) {
      var percentEl = document.getElementById("updatePercent");
      var bar = document.getElementById("updateProgressBar");
      var etaEl = document.getElementById("updateETA");
      var startBtn = document.getElementById("updateStartBtn");
      
      if (bar) { bar.style.background = "rgba(255,34,68,0.6)"; bar.style.animation = "none"; }
      if (percentEl) { percentEl.textContent = "❌"; percentEl.style.fontSize = "42px"; percentEl.style.color = "rgba(255,34,68,0.8)"; }
      if (etaEl) { etaEl.textContent = data.error || "فشل التحميل"; etaEl.style.color = "rgba(255,34,68,0.8)"; }
      if (startBtn) { startBtn.textContent = "فشل التحميل"; startBtn.style.background = "rgba(255,34,68,0.3)"; }
    } else {
      console.warn("Update download failed:", data.error);
      showToast("❌ فشل تحميل التحديث: " + (data.error || "خطأ غير معروف"), true);
    }
  }
};

// أضف animation style
if (!document.getElementById("updatePulseStyle")) {
  var style = document.createElement("style");
  style.id = "updatePulseStyle";
  style.textContent = "@keyframes updatePulse { 0%,100% { opacity: 0.6; } 50% { opacity: 1; } }";
  document.head.appendChild(style);
}
